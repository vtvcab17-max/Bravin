const response = require('../response');
const characterLibraryService = require('../services/characterLibraryService');

function routes(db, cfg, log) {
  return {
    list: (req, res) => {
      try {
        const query = { page: req.query.page, page_size: req.query.page_size, drama_id: req.query.drama_id, global: req.query.global, category: req.query.category, source_type: req.query.source_type, source_id: req.query.source_id, source_ids: req.query.source_ids, keyword: req.query.keyword };
        const { items, total, page, pageSize } = characterLibraryService.listLibraryItems(db, query);
        response.successWithPagination(res, items, total, page, pageSize);
      } catch (err) {
        log.error('character-library list', { error: err.message });
        response.internalError(res, err.message);
      }
    },
    create: (req, res) => {
      try {
        const item = characterLibraryService.createLibraryItem(db, log, req.body || {});
        response.created(res, item);
      } catch (err) {
        log.error('character-library create', { error: err.message });
        response.internalError(res, err.message);
      }
    },
    get: (req, res) => {
      try {
        const item = characterLibraryService.getLibraryItem(db, req.params.id);
        if (!item) return response.notFound(res, 'Mục trong kho nhân vật không tồn tại');
        response.success(res, item);
      } catch (err) {
        log.error('character-library get', { error: err.message });
        response.internalError(res, err.message);
      }
    },
    update: (req, res) => {
      try {
        const item = characterLibraryService.updateLibraryItem(db, log, req.params.id, req.body || {});
        if (!item) return response.notFound(res, 'Mục trong kho nhân vật không tồn tại');
        response.success(res, item);
      } catch (err) {
        log.error('character-library update', { error: err.message });
        response.internalError(res, err.message);
      }
    },
    delete: (req, res) => {
      try {
        const ok = characterLibraryService.deleteLibraryItem(db, log, req.params.id);
        if (!ok) return response.notFound(res, 'Mục trong kho nhân vật không tồn tại');
        response.success(res, { message: 'Xoá thành công' });
      } catch (err) {
        log.error('character-library delete', { error: err.message });
        response.internalError(res, err.message);
      }
    },
  };
}

module.exports = routes;
