const propService = require('../services/propService');
const propLibraryService = require('../services/propLibraryService');
const response = require('../response');

function listProps(db) {
  return (req, res) => {
    const props = propService.listByDramaId(db, req.params.id);
    response.success(res, props);
  };
}

function createProp(db, log) {
  return (req, res) => {
    const body = req.body || {};
    if (!body.drama_id || !body.name) return response.badRequest(res, 'drama_id và name là bắt buộc');
    try {
      const prop = propService.create(db, log, body);
      response.created(res, prop);
    } catch (err) {
      log.errorw('Create prop failed', { error: err.message });
      response.internalError(res, 'Tạo thất bại');
    }
  };
}

function updateProp(db, log) {
  return (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    const prop = propService.update(db, log, id, req.body || {});
    if (!prop) return response.notFound(res, 'Đạo cụ không tồn tại');
    response.success(res, prop);
  };
}

function deleteProp(db, log) {
  return (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    const ok = propService.deleteById(db, log, id);
    if (!ok) return response.notFound(res, 'Đạo cụ không tồn tại');
    response.success(res, { message: 'Xoá thành công' });
  };
}

function generateImage(db, log) {
  const propImageGenerationService = require('../services/propImageGenerationService');
  return (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    const model = req.body?.model != null ? String(req.body.model).trim() || null : null;
    const style = req.body?.style != null ? String(req.body.style).trim() || null : null;
    try {
      const taskId = propImageGenerationService.generatePropImage(db, log, id, { model, style });
      response.success(res, { task_id: taskId });
    } catch (err) {
      if (err.message === 'Đạo cụ không tồn tại') return response.notFound(res, err.message);
      if (err.message === 'Đạo cụ không có prompt ảnh') return response.badRequest(res, err.message);
      log.error('generatePropImage failed', { error: err.message });
      response.internalError(res, err.message || 'Tạo thất bại');
    }
  };
}

function extractProps(db, log, cfg) {
  const propExtractionService = require('../services/propExtractionService');
  return (req, res) => {
    const episodeId = req.params.episode_id;
    if (!episodeId) return response.badRequest(res, 'Thiếu episode_id');
    try {
      const taskId = propExtractionService.extractPropsForEpisode(db, log, episodeId, cfg);
      response.success(res, { task_id: taskId });
    } catch (err) {
      if (err.message === 'episode not found' || err.message?.includes('Nội dung kịch bản trống')) {
        return response.badRequest(res, err.message);
      }
      log.error('extractProps failed', { error: err.message });
      response.internalError(res, err.message || 'Trích xuất thất bại');
    }
  };
}

function associateProps(db, log) {
  return (req, res) => {
    const storyboardId = parseInt(req.params.id, 10);
    const propIds = Array.isArray(req.body?.prop_ids) ? req.body.prop_ids : [];
    propService.associateWithStoryboard(db, log, storyboardId, propIds);
    response.success(res, { message: 'Liên kết thành công' });
  };
}

function addToLibrary(db, log) {
  return (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    const out = propLibraryService.addPropToLibrary(db, log, id);
    if (!out.ok) {
      if (out.error === 'prop not found') return response.notFound(res, 'Đạo cụ không tồn tại');
      if (out.error === 'unauthorized') return response.forbidden(res, 'Không có quyền');
      return response.badRequest(res, out.error);
    }
    response.success(res, { message: 'Đã thêm vào kho đạo cụ của phim', item: out.item });
  };
}

function addToMaterialLibrary(db, log) {
  return (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    const out = propLibraryService.addPropToMaterialLibrary(db, log, id);
    if (!out.ok) {
      if (out.error === 'prop not found') return response.notFound(res, 'Đạo cụ không tồn tại');
      return response.badRequest(res, out.error);
    }
    response.success(res, { message: 'Đã thêm vào thư viện tư liệu chung', item: out.item });
  };
}

function getPropById(db, log) {
  return (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    const prop = propService.getById(db, id);
    if (!prop) return response.notFound(res, 'Đạo cụ không tồn tại');
    response.success(res, { prop });
  };
}

function generatePropPrompt(db, log, cfg) {
  return async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    try {
      const body = req.body || {};
      const out = await propService.generatePropPromptOnly(db, log, cfg, id, body.model || undefined, body.style || undefined);
      if (!out.ok) {
        if (out.error === 'prop not found') return response.notFound(res, 'Đạo cụ không tồn tại');
        return response.badRequest(res, out.error);
      }
      response.success(res, { message: 'Đã tạo prompt', prompt: out.prompt });
    } catch (err) {
      log.error('generatePropPrompt failed', { error: err.message });
      response.internalError(res, err.message);
    }
  };
}

function extractPropFromImage(db, log, cfg) {
  return async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return response.badRequest(res, 'ID không hợp lệ');
    try {
      const out = await propService.extractPropFromImage(db, log, cfg, id);
      if (!out.ok) {
        if (out.error === 'prop not found') return response.notFound(res, 'Đạo cụ không tồn tại');
        return response.badRequest(res, out.error);
      }
      response.success(res, { message: 'Đã trích xuất mô tả đạo cụ', description: out.description });
    } catch (err) {
      log.error('extractPropFromImage failed', { error: err.message });
      response.internalError(res, err.message);
    }
  };
}

module.exports = function propRoutes(db, log, cfg) {
  return {
    listProps: listProps(db),
    createProp: createProp(db, log),
    updateProp: updateProp(db, log),
    deleteProp: deleteProp(db, log),
    getPropById: getPropById(db, log),
    generateImage: generateImage(db, log),
    generatePropPrompt: generatePropPrompt(db, log, cfg),
    extractProps: extractProps(db, log, cfg),
    associateProps: associateProps(db, log),
    addToLibrary: addToLibrary(db, log),
    addToMaterialLibrary: addToMaterialLibrary(db, log),
    extractPropFromImage: extractPropFromImage(db, log, cfg),
  };
};
