# Thư mục FFmpeg

Đặt `ffmpeg.exe` (và `ffprobe.exe` nếu có) vào đây, máy chủ sẽ dùng trước, **không cần sửa biến môi trường**.

Gói LocalMiniDrama-vi không kèm `ffmpeg.exe` (99 MB) cho nhẹ. Lấy theo một trong hai cách:
- chép `backend-node/tools/ffmpeg/ffmpeg.exe` từ gói LocalMiniDrama gốc (LocalMiniDrama-main.zip) vào thư mục này;
- hoặc tải bản "essentials" ở https://www.gyan.dev/ffmpeg/builds/ rồi chép `bin/ffmpeg.exe`, `bin/ffprobe.exe` vào đây.

Có thể dùng lệnh (trong thư mục backend-node):
`node scripts/copy-ffmpeg.js "D:\ffmpeg\bin"`

Không có ffmpeg thì vẫn tạo được ảnh/video từng cảnh, chỉ không ghép được video cả tập và không trích khung cuối. macOS/Linux: cài ffmpeg vào PATH.
