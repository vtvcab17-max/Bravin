import { reactive } from 'vue'

/** 画布节点操作状态（生图/生视频/生成参考图等） */
export function createCanvasNodeStatusStore() {
  const map = reactive({})

  function set(nodeId, payload) {
    if (!nodeId) return
    if (!payload) {
      delete map[nodeId]
      return
    }
    map[nodeId] = {
      step: payload.step || 'busy',
      message: payload.message || 'Đang xử lý…',
      at: Date.now(),
    }
  }

  function clear(nodeId) {
    if (nodeId) delete map[nodeId]
  }

  function get(nodeId) {
    return nodeId ? map[nodeId] || null : null
  }

  function isBusy(nodeId) {
    return !!get(nodeId)
  }

  return { map, set, clear, get, isBusy }
}

export const CANVAS_NODE_STATUS_LABELS = {
  image: 'Đang tạo ảnh',
  video: 'Đang tạo video',
  audio: 'Đang lồng tiếng',
  polish: 'Đang trau chuốt',
  save: 'Đang lưu',
  ref_image: 'Tạo ảnh tham chiếu',
  generate_sb: 'AI tạo phân cảnh',
  save_script: 'Lưu kịch bản',
  extract_chars: 'Tách nhân vật',
  extract_scenes: 'Tách bối cảnh',
  extract_props: 'Tách đạo cụ',
  extract_all: 'Tách tất cả',
}
