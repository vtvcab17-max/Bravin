/** 自定义画风：dramas.style 固定短标识，完整描述写在 metadata.style_prompt_* */
export const CUSTOM_STYLE_VALUE = 'custom'

/** 影像风格选项 - 静态配置数据 */
export const generationStyleOptions = [
  {
    label: 'Tả thực / điện ảnh',
    options: [
      { label: 'Tả thực',    value: 'realistic',
        prompt:   'Phong cách nhiếp ảnh siêu thực, chi tiết siêu nét 8K, ánh sáng tự nhiên chuẩn xác, kết cấu da thật, quay bằng máy chuyên nghiệp, chất ảnh RAW, độ nét cực cao, thấy rõ lỗ chân lông trên mặt',
        promptEn: 'photorealistic, ultra-detailed, 8k uhd, sharp focus, natural lighting, real skin texture, hyperrealism, professional photography, RAW photo',
        color: 'linear-gradient(135deg,#c9a87c,#7c5e3c)', thumb: '/style-thumbs/realistic.jpg' },
      { label: 'Chất điện ảnh',  value: 'cinematic',
        prompt:   'Hình ảnh bom tấn điện ảnh, cảm giác nén của ống kính anamorphic, hạt phim, chiếu sáng kịch tính kiểu Rembrandt, xoá phông nông, chỉnh màu chuyên nghiệp, bố cục hoành tráng, thẩm mỹ phim 35mm, khung hình màn ảnh rộng',
        promptEn: 'cinematic movie still, anamorphic lens, film grain, dramatic rembrandt lighting, shallow depth of field, color graded, epic composition, professional cinematography, 35mm film, widescreen',
        color: 'linear-gradient(135deg,#1a1a2e,#c9aa71)', thumb: '/style-thumbs/cinematic.jpg' },
      { label: 'Phim tài liệu',  value: 'documentary',
        prompt:   'Phong cách quay tài liệu, ánh sáng tự nhiên có sẵn, khoảnh khắc thật bắt được, cảm giác rung máy cầm tay, thẩm mỹ phóng sự ảnh, chất thô chân thực, hạt phim, trạng thái tự nhiên không dàn dựng',
        promptEn: 'documentary photography style, natural available light, candid authentic moment, handheld camera look, photojournalism, raw gritty realism, grain texture, unposed',
        color: 'linear-gradient(135deg,#4a6741,#8fbc8f)', thumb: '/style-thumbs/documentary.jpg' },
      { label: 'Phim noir', value: 'noir',
        prompt:   'Phong cách phim noir, đen trắng tương phản cao, sáng tối khắc mạnh, vệt sáng qua rèm chớp, không khí phim trinh thám thập niên 1940, chất bí ẩn hồi hộp, khói mờ và phố đêm mưa',
        promptEn: 'film noir, dramatic high-contrast black and white, hard chiaroscuro shadows, venetian blind light patterns, moody 1940s detective aesthetic, mystery atmosphere, smoke and rain',
        color: 'linear-gradient(135deg,#1a1a1a,#666)',    thumb: '/style-thumbs/noir.jpg' },
      { label: 'Phim cũ hoài cổ', value: 'retro film',
        prompt:   'Thẩm mỹ phim nhựa cổ điển, màu Kodak, hiệu ứng lọt sáng và quầng sáng, hạt phim 35mm dày, tông ấm phai màu, chất phim analog, không khí hoài cổ, hơi dư sáng',
        promptEn: 'vintage retro film photography, kodachrome color palette, light leaks, heavy 35mm grain, faded warm tones, analog film aesthetics, nostalgic atmosphere, slightly overexposed',
        color: 'linear-gradient(135deg,#d4a373,#8b6914)', thumb: '/style-thumbs/retro.jpg' },
      { label: 'Kinh dị',    value: 'horror',
        prompt:   'Không khí kinh dị, cảm xúc u ám ngột ngạt, sương mù dày, bóng đổ nặng kịch tính, ánh sáng lạnh rợn người, bố cục gây bất an, điểm xuyết yếu tố gothic, bảng màu tối giảm bão hoà, căng thẳng tâm lý',
        promptEn: 'horror atmosphere, dark ominous mood, dense atmospheric fog, deep dramatic shadows, eerie cold lighting, unsettling composition, gothic elements, desaturated dark palette, psychological tension',
        color: 'linear-gradient(135deg,#1a0a0a,#7b1111)', thumb: '/style-thumbs/horror.jpg' },
    ]
  },
  {
    label: 'Anime / hoạt hình',
    options: [
      { label: 'Anime Nhật', value: 'anime style',
        prompt:   'Phong cách anime Nhật, tô màu cel tinh tế, nét đen rõ ràng, màu tươi bão hoà cao, thiết kế nhân vật giàu biểu cảm, chất lượng xưởng hoạt hình, ảnh hưởng thẩm mỹ manga, phong cách minh hoạ khung hình chính',
        promptEn: 'anime style, Japanese animation, clean cel shading, precise black linework, vibrant saturated colors, expressive character design, studio quality, manga influence, key visual illustration',
        color: 'linear-gradient(135deg,#ff9fd2,#a97cdb)', thumb: '/style-thumbs/anime.jpg' },
      { label: 'Truyện tranh Âu Mỹ', value: 'comic style',
        prompt:   'Phong cách truyện tranh Âu Mỹ, nét mực đậm khoẻ, chấm halftone, bố cục hành động giàu chuyển động, màu phẳng rực rỡ, thẩm mỹ minh hoạ siêu anh hùng, hiệu ứng tô mực chia khung',
        promptEn: 'western comic book style, bold ink linework, halftone dot texture, dynamic action composition, flat vibrant colors, superhero illustration aesthetic, inked and colored panels',
        color: 'linear-gradient(135deg,#4169e1,#ff6b47)', thumb: '/style-thumbs/comic.jpg' },
      { label: 'Hoạt hình',    value: 'cartoon',
        prompt:   'Phong cách minh hoạ hoạt hình, viền ngoài đơn giản đậm, mảng màu phẳng, biểu cảm và động tác cường điệu, thiết kế vui tươi thân thiện, phong cách phim hoạt hình Âu Mỹ, chất hình vector sạch',
        promptEn: 'cartoon illustration, simple bold outlines, flat solid colors, exaggerated expressive features, playful friendly design, western animation style, clean vector-like quality',
        color: 'linear-gradient(135deg,#ffd700,#ff6b6b)', thumb: '/style-thumbs/cartoon.jpg' },
      { label: 'Hoạt hình 2D', value: '2d animation',
        prompt:   'Phong cách hoạt hình 2D, khung hình động mượt, thiết kế phẳng sạch, viền đậm, màu tươi bão hoà, chất lượng phim hoạt hình chiếu rạp, thẩm mỹ minh hoạ khung hình chính',
        promptEn: '2D animation style, smooth animated frame, clean flat design, bold outlines, vibrant colors, animated feature film quality, keyframe illustration',
        color: 'linear-gradient(135deg,#43e97b,#38f9d7)', thumb: '/style-thumbs/2d-animation.jpg' },
      { label: 'Anime tả thực', value: 'realistic anime',
        prompt:   'Phong cách anime tả thực, tỉ lệ và gương mặt tinh xảo kiểu anime, chi tiết da và tóc như thật, tô màu cel pha bán tả thực mềm, ánh sáng thể tích và phản chiếu môi trường chuẩn điện ảnh, bối cảnh đô thị hiện đại hoặc nội thất thật, bố cục như qua ống kính và xoá phông nông, giữ nét viền anime rõ mà vẫn có chất liệu điện ảnh, khí chất hình quảng bá anime Nhật và Trung chất lượng cao',
        promptEn: 'realistic anime style, anime character proportions with refined facial features, realistic skin texture and detailed hair strands, hybrid cel shading and soft semi-realistic rendering, cinematic volumetric lighting and environment reflections, modern urban or interior real-world setting, cinematic composition with shallow depth of field, keep clean anime linework while preserving film-grade material realism, high-end Japanese and Chinese anime promotional visual aesthetic',
        color: 'linear-gradient(135deg,#7c83fd,#2dd4bf)', thumb: '/style-thumbs/realisticanime.png' },
      { label: '3D đô thị', value: 'urban 3d',
        prompt:   'Phong cách 3D đô thị, phố xá với nhà chọc trời và tường kính hiện đại, kết cấu thép bê tông và phản chiếu kim loại, vật liệu PBR và chiếu sáng toàn cục dịu, phản chiếu bầu trời và kiến trúc, xe cộ và người đi đường hơi mờ theo chiều sâu, render 3D sạch thiên tả thực, khí chất CG phim đô thị và quảng cáo, che khuất môi trường chi tiết cao và chút sương thể tích',
        promptEn: 'urban contemporary 3D CGI, modern skyscrapers and glass curtain wall streetscape, steel concrete architecture with subtle metal reflections, PBR materials soft global illumination sky and building reflections, gentle depth of field for traffic and pedestrian silhouettes, clean semi-realistic 3D render Chinese urban drama and commercial CG aesthetic, high detail ambient occlusion light atmospheric haze',
        color: 'linear-gradient(135deg,#1e3a5f,#38bdf8)', thumb: '/style-thumbs/3d-render.jpg' },
    ]
  },
  {
    label: 'Phong cách Trung Hoa',
    options: [
      { label: 'Tranh thuỷ mặc', value: 'ink wash',
        prompt:   'Phong cách tranh thuỷ mặc truyền thống Trung Hoa, kỹ pháp bát mặc tả ý, mực một màu loang, nét bút lông trúc, bố cục tối giản nhiều khoảng trống, chất giấy Tuyên, không khí mây mù thơ mộng, kết hợp công bút và tả ý',
        promptEn: 'traditional Chinese ink wash painting, sumi-e style, monochrome brushwork, bamboo brush strokes, minimalist composition, generous negative space, xuan paper texture, poetic misty atmosphere, guohua style',
        color: 'linear-gradient(135deg,#e8e0d5,#8b7355)', thumb: '/style-thumbs/ink-wash.jpg' },
      { label: 'Phong cách cổ trang Trung Hoa',  value: 'chinese style',
        prompt:   'Thẩm mỹ truyền thống Trung Hoa, Hán phục tinh xảo, đồ vật son đỏ thếp vàng, hoa văn thêu công phu, yếu tố thiết kế thời Minh Thanh, kiến trúc cổ và đình đài lầu các, ý cảnh sâu xa',
        promptEn: 'Chinese traditional aesthetics, elegant hanfu costumes, red lacquer and gold ornaments, intricate embroidered patterns, Ming-Qing dynasty design elements, classical architecture, atmospheric depth',
        color: 'linear-gradient(135deg,#c0392b,#8b0000)', thumb: '/style-thumbs/chinese.jpg' },
      { label: 'Cổ trang',    value: 'historical',
        prompt:   'Phong cách phim cổ trang lịch sử Trung Hoa, thẩm mỹ điện ảnh thời Đường Tống, Hán phục tay rộng bay bổng, cung điện, vườn cảnh cổ điển, chỉnh màu ấm đậm, chất phim đầu tư cao',
        promptEn: 'Chinese historical drama, ancient China setting, Tang-Song dynasty cinematic aesthetic, flowing traditional hanfu robes, imperial palace architecture, classical garden, rich warm color grading, high production value',
        color: 'linear-gradient(135deg,#d4af37,#8b5e14)', thumb: '/style-thumbs/historical.jpg' },
      { label: 'Võ hiệp',    value: 'wuxia',
        prompt:   'Phong cách sử thi võ hiệp, nền non sông Trung Hoa cổ đại, áo lụa dài tung bay, cảnh sơn thuỷ mây mù huyền ảo, tư thế đấu kiếm kịch tính, ảnh hưởng không khí thuỷ mặc, thẩm mỹ anh hùng hiệp khách, bố cục điện ảnh khổ rộng hoành tráng, không khí hồi hộp quyện khói và ánh sáng',
        promptEn: 'wuxia martial arts epic, ancient China, flowing silk robes in dynamic motion, misty mountain landscape, dramatic sword fighting pose, atmospheric ink wash influence, hero and swordsman aesthetic, cinematic epic wide shot, moody fog and light rays',
        color: 'linear-gradient(135deg,#2c3e50,#3498db)', thumb: '/style-thumbs/wuxia.jpg' },
    ]
  },
  {
    label: 'Truyện tranh Trung / ngôn tình hiện đại',
    options: [
      { label: 'Cổ phong 2D', value: '2d gufeng',
        prompt:   'Minh hoạ cổ phong 2D Trung Quốc, nét mảnh và tô cel phẳng, màu thanh nhã ít bão hoà, Hán phục và trang sức tóc vẽ kỹ, đình đài lầu các hoặc sơn thuỷ nhiều khoảng trống, khí chất bìa truyện mạng và thiết kế nhân vật phim hoạt hình, vẽ số sạch không nhiễu',
        promptEn: 'Chinese 2D guofeng illustration, delicate linework and cel shading, soft muted elegant palette, detailed hanfu and hair ornaments, pavilion or misty landscape, web novel cover and donghua character art style, clean digital painting',
        color: 'linear-gradient(135deg,#e8dcc8,#9b7653)', thumb: '/style-thumbs/2d-gufeng.jpg' },
      { label: 'Tiên hiệp 3D', value: 'xianxia 3d',
        prompt:   'Render 3D tiên hiệp huyền huyễn, không khí tiên cảnh thoát tục, dòng linh lực và hạt phép thuật, áo tiên tay rộng và mũ ngọc, biển mây núi lạ và cung khuyết lầu gác, thẩm mỹ phim tiên hiệp và CG game Trung Quốc, ánh sáng thể tích dịu và chiều sâu trường ảnh',
        promptEn: 'Chinese xianxia fantasy 3D render, ethereal immortal realm, spiritual glow and spell particles, flowing immortal robes and jade hair crown, sea of clouds and celestial palace, Chinese fantasy drama and game CG aesthetic, soft volumetric light and depth of field',
        color: 'linear-gradient(135deg,#1a3a52,#7ec8e3)', thumb: '/style-thumbs/xianxia-3d.jpg' },
      { label: 'Cổ phong 3D', value: 'gufeng 3d',
        prompt:   'Nhân vật và bối cảnh 3D cổ phong tả thực, da tán xạ dưới bề mặt và vải lụa, búi tóc cao với trâm cài chi tiết, cung điện vườn cảnh hoặc phố chợ, phục trang đạo cụ cấp phim cổ trang, chỉnh màu điện ảnh tông ấm, tinh xảo mà không quá hoạt hình',
        promptEn: 'Chinese historical 3D realistic character and scene, subsurface skin and silk fabric detail, elaborate hairpins and hanfu, palace garden or ancient street, costume drama level production design, warm cinematic color grading, refined semi-realistic 3D',
        color: 'linear-gradient(135deg,#5c4033,#c9a227)', thumb: '/style-thumbs/gufeng-3d.jpg' },
      { label: 'Tân Trung Hoa quốc triều', value: 'neo chinese guochao',
        prompt:   'Thị giác tân Trung Hoa quốc triều, hoa văn truyền thống và nét thư pháp hoà vào thiết kế đồ hoạ hiện đại, màu tương phản bão hoà cao điểm neon, mây lành rồng thuỷ mặc được hình học hoá, chất minh hoạ áp phích, trẻ trung hợp mốt cùng biểu tượng phương Đông',
        promptEn: 'neo-Chinese guochao graphic style, traditional patterns and brush strokes in modern flat design, bold saturated colors with neon accents, stylized clouds dragons ink geometry, poster illustration vibe, youthful street fashion meets oriental motifs',
        color: 'linear-gradient(135deg,#c41e3a,#1a1a2e)', thumb: '/style-thumbs/neo-chinese-guochao.jpg' },
      { label: 'Tân cổ phong', value: 'neo gufeng',
        prompt:   'Minh hoạ tân cổ phong, ý cảnh cổ điển nhưng tươi sáng hơn, viền mềm và chuyển sắc tinh tế, hay gặp ở đề tài ngôn tình và tiên hiệp, nhân vật đẹp biểu cảm tinh tế, nền thuỷ mặc mờ ảo mà không nặng nề, hợp bìa khổ dọc',
        promptEn: 'neo guofeng illustration, classical mood with fresh bright tones, soft edges and smooth gradients, romance and xianxia novel aesthetic, delicate faces and expressive eyes, misty ink wash background, vertical cover art composition',
        color: 'linear-gradient(135deg,#f5e6d3,#b8860b)', thumb: '/style-thumbs/neo-gufeng.jpg' },
      { label: 'Truyện tranh ngôn tình đô thị', value: 'urban romance comic',
        prompt:   'Phong cách truyện tranh ngôn tình đô thị hiện đại, tô màu sáng trong, cảnh văn phòng quán cà phê đường phố, nhân vật đẹp mắt to mũi môi giản lược, cảm giác truyện cuộn dọc, điểm ánh sao hoặc đốm sáng lãng mạn, khí chất ngọt ngào của truyện ngôn tình Trung Quốc',
        promptEn: 'urban contemporary romance manhua style, bright clean coloring, office cafe city street backgrounds, pretty stylized faces big eyes, webcomic panel feel, sparkle and soft bokeh romantic lighting, sweet modern Chinese romance comic aesthetic',
        color: 'linear-gradient(135deg,#ffeef8,#a78bfa)', thumb: '/style-thumbs/urban-romance-comic.jpg' },
      { label: 'Webtoon tình yêu Hàn', value: 'korean romance webtoon',
        prompt:   'Phong cách webtoon tình yêu Hàn Quốc, nét vẽ tối giản sạch, màu pastel và chuyển sắc dịu, nhân vật thanh tú trẻ trung, bố cục dọc nhiều khoảng trống, không khí rung động mối tình đầu, bóng viền mềm và điểm sáng, giống truyện tranh mạng tình cảm Hàn',
        promptEn: 'Korean romance webtoon style, clean minimal linework, soft pastel gradients, delicate youthful characters, vertical scroll composition, innocent first love mood, soft cel shading and highlights, Korean BL or romance manhwa aesthetic',
        color: 'linear-gradient(135deg,#ffd6e8,#b4a7d6)', thumb: '/style-thumbs/korean-romance-webtoon.jpg' },
    ]
  },
  {
    label: 'Nghệ thuật hội hoạ',
    options: [
      { label: 'Màu nước',    value: 'watercolor',
        prompt:   'Phong cách tranh màu nước, lớp màu ướt chồng viền mềm, màu trong suốt loang, màu chảy lan tự nhiên, chất sợi giấy, nét cọ ấn tượng, tông sáng dịu, minh hoạ vẽ tay tinh xảo',
        promptEn: 'watercolor painting, soft wet-on-wet edges, transparent color washes, flowing pigment blooms, delicate paper texture, impressionistic strokes, luminous pastel tones, fine art illustration',
        color: 'linear-gradient(135deg,#a8d8ea,#ffd3b6)', thumb: '/style-thumbs/watercolor.jpg' },
      { label: 'Sơn dầu',    value: 'oil painting',
        prompt:   'Phong cách sơn dầu trên toan, chất màu đắp dày, nét cọ khoẻ có hướng, màu sâu bão hoà, sáng tối kiểu bậc thầy cổ điển, tác phẩm tầm bảo tàng, kế thừa thẩm mỹ Phục Hưng',
        promptEn: 'oil painting on canvas, rich impasto textures, thick directional brushwork, deep saturated colors, old master chiaroscuro lighting, museum quality fine art, classical Renaissance aesthetic',
        color: 'linear-gradient(135deg,#d4a76a,#6b3728)', thumb: '/style-thumbs/oil-painting.jpg' },
      { label: 'Ký hoạ',    value: 'sketch',
        prompt:   'Ký hoạ bút chì tỉ mỉ, chất than chì, đan nét và gạch chéo chính xác, xử lý độ đậm nhạt, chất sổ ký hoạ mỹ thuật, đen trắng đơn sắc, sức căng nghệ thuật nguyên sơ, kết cấu than trên giấy',
        promptEn: 'detailed pencil sketch, graphite drawing, precise hatching and crosshatching, tonal shading, fine art sketchbook quality, monochrome, raw artistic energy, charcoal texture',
        color: 'linear-gradient(135deg,#f0f0f0,#888)',    thumb: '/style-thumbs/sketch.jpg' },
      { label: 'Tranh khắc',    value: 'woodblock print',
        prompt:   'Phong cách tranh khắc gỗ truyền thống, thẩm mỹ ukiyo-e, mảng màu phẳng lớn, bảng màu hạn chế hài hoà, thẩm mỹ làm tranh khắc Nhật Bản, đường nét đồ hoạ, bố cục kiểu Hokusai',
        promptEn: 'traditional woodblock print, ukiyo-e inspired, bold flat color areas, limited harmonious palette, Japanese printmaking aesthetic, graphic linework, Hokusai style composition',
        color: 'linear-gradient(135deg,#4a3728,#c9a87c)', thumb: '/style-thumbs/woodblock.jpg' },
      { label: 'Ấn tượng',  value: 'impressionist',
        prompt:   'Phong cách sơn dầu ấn tượng, nét cọ phóng khoáng giàu biểu cảm, nắng loang lổ, màu bổ túc rực rỡ, phong cách Monet Renoir, vẽ ngoài trời ánh sáng tự nhiên, ánh sáng và màu quyện vào không khí',
        promptEn: 'impressionist oil painting, loose expressive brushstrokes, dappled sunlight effect, vibrant complementary colors, Monet-Renoir style, plein air outdoor painting, atmospheric light and color',
        color: 'linear-gradient(135deg,#7ec8e3,#f9c74f)', thumb: '/style-thumbs/impressionist.jpg' },
    ]
  },
  {
    label: 'Kỳ ảo / khoa học viễn tưởng',
    options: [
      { label: 'Kỳ ảo',    value: 'fantasy',
        prompt:   'Nghệ thuật số kỳ ảo sử thi, không khí huyền diệu thoát tục, ánh sáng giờ vàng kịch tính, sinh vật thần thoại và thế giới phép thuật, toàn cảnh hùng vĩ, concept art cực chi tiết, chất minh hoạ hội hoạ',
        promptEn: 'epic fantasy digital art, magical ethereal atmosphere, dramatic golden hour lighting, mythical creatures and enchanted world, sweeping landscape, highly detailed concept art, painterly illustration quality',
        color: 'linear-gradient(135deg,#6a0572,#e8b86d)', thumb: '/style-thumbs/fantasy.jpg' },
      { label: 'Kỳ ảo u tối', value: 'dark fantasy',
        prompt:   'Phong cách kỳ ảo u tối, không khí gothic ảm đạm, tông màu tối nặng nề, ánh sáng viền kịch tính, yếu tố huyền bí kiểu Cthulhu, chi tiết baroque cầu kỳ, thế giới khắc nghiệt thô ráp, kinh dị pha kỳ ảo',
        promptEn: 'dark fantasy art, gothic ominous atmosphere, brooding dark palette, dramatic rim lighting, eldritch and arcane elements, baroque ornate detail, grim and gritty world, horror fantasy crossover',
        color: 'linear-gradient(135deg,#0d0d0d,#6b0f1a)', thumb: '/style-thumbs/dark-fantasy.jpg' },
      { label: 'Khoa học viễn tưởng',    value: 'sci-fi',
        prompt:   'Concept art khoa học viễn tưởng, yếu tố công nghệ tương lai, giao diện chiếu hologram, thẩm mỹ thiết kế nền văn minh tiên tiến, chất sci-fi gọn gàng, vật liệu thời đại vũ trụ, giao diện tương tác phát sáng, phong cách hard sci-fi tả thực',
        promptEn: 'science fiction concept art, futuristic technology, holographic displays, sleek advanced civilization design, clean sci-fi aesthetic, space age materials, glowing interfaces, hard sci-fi realism',
        color: 'linear-gradient(135deg,#0a0a2e,#00d4ff)', thumb: '/style-thumbs/sci-fi.jpg' },
      { label: 'Cyberpunk', value: 'cyberpunk',
        prompt:   'Thẩm mỹ cyberpunk, phố sau mưa ngập ánh neon, siêu đô thị phản địa đàng, thế giới công nghệ cao đời sống thấp, bảng quảng cáo phát sáng san sát, đêm mưa đen kịt, hồng tím neon và xanh điện, khí chất noir kiểu Blade Runner',
        promptEn: 'cyberpunk aesthetic, neon-soaked rain-slicked streets, dystopian megacity, high tech low life, glowing advertising billboards, dark wet night, neon pink magenta and electric blue, blade runner noir atmosphere',
        color: 'linear-gradient(135deg,#0d0221,#ff00ff)', thumb: '/style-thumbs/cyberpunk.jpg' },
      { label: 'Steampunk', value: 'steampunk',
        prompt:   'Thẩm mỹ steampunk, kỳ ảo công nghiệp thời Victoria, bánh răng đồng thau bóng và ống đồng, máy móc chạy hơi nước, tông nâu ấm, cơ cấu cơ khí tinh xảo, kính bảo hộ và mũ chóp, chi tiết bộ máy đồng hồ lộng lẫy',
        promptEn: 'steampunk aesthetic, Victorian era industrial fantasy, polished brass gears and copper cogs, steam powered machinery, sepia warm tones, elaborate mechanical contraptions, goggles and top hats, ornate clockwork',
        color: 'linear-gradient(135deg,#3d2b1f,#c87941)', thumb: '/style-thumbs/steampunk.jpg' },
      { label: 'Hoang tàn tận thế', value: 'post-apocalyptic',
        prompt:   'Hoang mạc tận thế, tàn tích nền văn minh sụp đổ, tông xám ít bão hoà, không khí sinh tồn tận thế, nhà cửa mục nát và đổ nát, bụi và đá vụn đầy trời, ánh sáng kịch tính mạnh, thẩm mỹ Mad Max',
        promptEn: 'post-apocalyptic wasteland, ruined crumbling civilization, harsh desaturated color palette, survival atmosphere, decayed architecture, dust and debris, harsh dramatic light, Mad Max aesthetic',
        color: 'linear-gradient(135deg,#3d3117,#8b7355)', thumb: '/style-thumbs/post-apoc.jpg' },
    ]
  },
  {
    label: 'Số / hiện đại',
    options: [
      { label: 'Render 3D', value: '3d render',
        prompt:   'Render CGI 3D, chiếu sáng toàn cục dò tia, chất tả thực tán xạ dưới bề mặt, chiếu sáng studio HDRI, mô hình đa giác độ chính xác cao, quy trình render vật lý, chất lượng cỡ Octane hoặc Redshift, độ chính xác trình diễn sản phẩm',
        promptEn: '3D CGI render, ray tracing global illumination, photorealistic subsurface scattering, studio HDRI lighting, high polygon model, physically based rendering, Octane or Redshift quality, product visualization',
        color: 'linear-gradient(135deg,#1a1a2e,#4facfe)', thumb: '/style-thumbs/3d-render.jpg' },
      { label: 'Pixel art',  value: 'pixel art',
        prompt:   'Phong cách pixel art, thẩm mỹ game cổ điển 16 bit, bảng màu hạn chế, điểm ảnh sắc cạnh rõ ràng, chất sprite, phong cách hình ảnh RPG Nhật cổ điển, màn hình game isometric hoặc cuộn ngang',
        promptEn: 'pixel art, 16-bit retro game aesthetic, limited color palette, crisp hard pixels, sprite art style, classic JRPG visual, isometric or side-scroll game art',
        color: 'linear-gradient(135deg,#6272a4,#50fa7b)', thumb: '/style-thumbs/pixel-art.jpg' },
      { label: 'Low poly', value: 'low poly',
        prompt:   'Nghệ thuật hình học low poly, mặt cắt tam giác phẳng, số đa giác tối giản, các mặt màu sạch ghép lại, thẩm mỹ hình học hiện đại, kiểu origami 3D, chất nghệ thuật số trừu tượng',
        promptEn: 'low poly geometric art, flat triangular faceted surfaces, minimal polygon count, clean colorful facets, modern geometric aesthetic, 3D origami style, abstract digital art',
        color: 'linear-gradient(135deg,#2193b0,#6dd5ed)', thumb: '/style-thumbs/low-poly.jpg' },
      { label: 'Tối giản',    value: 'minimalist',
        prompt:   'Thẩm mỹ thiết kế tối giản, bố cục sạch không rối, nhiều khoảng trống thoáng, hình khối hình học đơn giản, bảng màu đơn sắc hạn chế, chủ nghĩa hiện đại Bauhaus, vẻ đẹp giản dị thanh lịch tiết chế',
        promptEn: 'minimalist design, clean uncluttered composition, generous negative space, simple geometric forms, limited monochromatic palette, modern Bauhaus aesthetic, sophisticated elegant simplicity',
        color: 'linear-gradient(135deg,#e0e0e0,#bdbdbd)', thumb: '/style-thumbs/minimalist.jpg' },
      { label: 'Mộng mơ duy mỹ', value: 'dreamy',
        prompt:   'Thẩm mỹ mộng mơ duy mỹ, nền mờ màu kem, tông pastel dịu, không khí phát sáng thoát tục, ánh sáng mềm lãng mạn, sương mỏng và quầng sáng tinh tế, chất phép màu cổ tích, cảm giác mơ màng lấy nét mềm',
        promptEn: 'dreamy aesthetic, creamy soft bokeh background, pastel color palette, ethereal glowing atmosphere, romantic soft lighting, delicate haze and glow, fairy tale magical quality, soft focus dreamy',
        color: 'linear-gradient(135deg,#ffecd2,#fcb69f)', thumb: '/style-thumbs/dreamy.jpg' },
    ]
  },
]

/**
 * 根据 value 查找风格选项对象
 * @param {string} val
 * @returns {object|null}
 */
export function findStyleOption(val) {
  for (const group of generationStyleOptions) {
    const found = group.options.find(o => o.value === val)
    if (found) return found
  }
  return null
}

/**
 * 获取传给图像/视频 AI 用的英文 prompt（效果最好）
 * @param {string} val - 风格 value
 * @returns {string|undefined}
 */
export function getStylePromptEn(val) {
  const v = (val || '').toString().trim()
  if (!v) return undefined
  // 无第二参数时无法拿到用户描述；勿把短标识 custom 当提示词
  if (v === CUSTOM_STYLE_VALUE) return undefined
  const opt = findStyleOption(v)
  if (opt) return opt.promptEn || opt.prompt || v
  return v
}

/**
 * 获取中文风格描述（用于界面展示或中文场景提示词拼接）
 * @param {string} val - 风格 value
 * @returns {string|undefined}
 */
export function getStylePromptZh(val) {
  const v = (val || '').toString().trim()
  if (!v) return undefined
  if (v === CUSTOM_STYLE_VALUE) return undefined
  const opt = findStyleOption(v)
  if (opt) return opt.prompt || opt.promptEn || v
  return v
}

/**
 * 保存剧集 metadata 时用：与后端约定字段 style_prompt_zh / style_prompt_en。
 * 未选风格时返回空串，写入后可覆盖旧 metadata 中的画风字段。
 * 自定义画风（custom）时第二参数为用户描述，zh/en 写入同一文本。
 */
export function stylePromptMetadataForSave(styleValue, customPrompt) {
  const v = (styleValue || '').toString().trim()
  if (!v) return { style_prompt_zh: '', style_prompt_en: '' }
  if (v === CUSTOM_STYLE_VALUE) {
    const text = (customPrompt != null ? String(customPrompt) : '').trim()
    return { style_prompt_zh: text, style_prompt_en: text }
  }
  const opt = findStyleOption(v)
  if (!opt) return { style_prompt_zh: v, style_prompt_en: v }
  return {
    style_prompt_zh: opt.prompt || opt.promptEn || '',
    style_prompt_en: opt.promptEn || opt.prompt || '',
  }
}

/** 列表/触发器展示用中文名 */
export function getStyleLabel(val) {
  const v = (val || '').toString().trim()
  if (!v) return ''
  if (v === CUSTOM_STYLE_VALUE) return 'Tuỳ chỉnh'
  const opt = findStyleOption(v)
  return opt?.label || v
}

/**
 * 旧项目只有 dramas.style（value）而 metadata 里没有画风长文案时，自动 saveOutline 合并写入，
 * 便于后端 mergeCfgStyleWithDrama 能拿到 default_style_en。不覆盖已有 style_prompt_en。
 * @returns {Promise<object>} 更新后的剧集对象（失败或未改则原样返回 drama）
 */
export async function backfillDramaStylePromptMetadataIfNeeded(dramaAPI, dramaId, drama) {
  if (!drama || dramaId == null) return drama
  const styleVal = (drama.style || '').toString().trim()
  if (!styleVal) return drama
  if (styleVal === CUSTOM_STYLE_VALUE) return drama
  const hasEn = (drama.metadata?.style_prompt_en || '').toString().trim()
  if (hasEn) return drama
  const patch = stylePromptMetadataForSave(styleVal)
  if (!(patch.style_prompt_en || '').toString().trim()) return drama
  try {
    await dramaAPI.saveOutline(dramaId, { metadata: patch })
    return await dramaAPI.get(dramaId)
  } catch (_) {
    return drama
  }
}
