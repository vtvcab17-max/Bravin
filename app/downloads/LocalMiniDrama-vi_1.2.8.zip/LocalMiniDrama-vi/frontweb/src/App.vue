<template>
  <div class="app">
    <router-view />
    <BravinDock />
  </div>
</template>

<script setup lang="ts">
import BravinDock from './components/BravinDock.vue'
</script>

<style>
* {
  box-sizing: border-box;
}
html, body, #app, .app {
  font-family: "Be Vietnam Pro", "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "PingFang SC", "Microsoft YaHei", sans-serif;
  margin: 0;
  padding: 0;
  min-height: 100vh;
  background: var(--bg-page);
  color: var(--text-primary);
  transition: background 0.25s, color 0.25s;
}
</style>
