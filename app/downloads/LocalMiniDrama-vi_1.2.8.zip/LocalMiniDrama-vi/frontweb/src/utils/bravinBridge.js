// Cầu nối LocalMiniDrama ↔ Bravin (khi LMD chạy trong khung "Phim AI" của Bravin).
// Giao thức postMessage: { source: 'lmd' | 'bravin', type, ... }
import { reactive } from 'vue'
import request from './request'

export const BRIDGE_VERSION = 1
export const LMD_VERSION = '1.2.8-vi'

export const bravin = reactive({
  embedded: false,
  connected: false, // Bravin đã trả lời
  autoPush: true,
  bravinVersion: '',
  bravinProject: '', // tên dự án Bravin đang mở
  drama: null, // { id, title, aspect_ratio }
  lastPush: null, // { count, at }
})

function post(type, payload = {}) {
  if (!bravin.embedded) return
  try { window.parent.postMessage({ source: 'lmd', type, ...payload }, '*') } catch (_) {}
}

export function requestNewProject() {
  if (!bravin.drama) return false
  post('new-project', { drama: { ...bravin.drama } })
  return true
}

export function requestSyncNow() {
  post('sync-now', { drama: bravin.drama ? { ...bravin.drama } : null })
}

let ctxSeq = 0
async function updateContext(route) {
  const seq = ++ctxSeq
  const name = route?.name
  const id = route?.params?.id
  let drama = null
  if (id && ['film', 'drama-detail', 'film-canvas'].includes(String(name))) {
    try {
      const d = await request.get(`/dramas/${id}`)
      let meta = d?.metadata
      if (typeof meta === 'string') { try { meta = JSON.parse(meta) } catch (_) { meta = {} } }
      drama = { id: Number(d?.id ?? id), title: String(d?.title || `Phim ${id}`), aspect_ratio: meta?.aspect_ratio || '16:9' }
    } catch (_) {
      drama = { id: Number(id), title: `Phim ${id}`, aspect_ratio: '16:9' }
    }
  }
  if (seq !== ctxSeq) return
  bravin.drama = drama
  post('context', { drama })
}

export function initBravinBridge(router) {
  let embedded = false
  try { embedded = window.parent && window.parent !== window } catch (_) { embedded = true }
  bravin.embedded = embedded
  if (!embedded) return
  document.documentElement.classList.add('in-bravin')
  window.addEventListener('message', (ev) => {
    const m = ev.data
    if (!m || m.source !== 'bravin') return
    switch (m.type) {
      case 'ping':
        bravin.connected = true
        if (m.version) bravin.bravinVersion = m.version
        post('hello', { version: LMD_VERSION, bridge: BRIDGE_VERSION, features: ['context', 'new-project', 'sync-now'] })
        post('context', { drama: bravin.drama })
        break
      case 'state':
        bravin.connected = true
        if (typeof m.autoPush === 'boolean') bravin.autoPush = m.autoPush
        if (m.project != null) bravin.bravinProject = String(m.project)
        break
      case 'pushed':
        bravin.lastPush = { count: m.count || 0, at: Date.now(), names: m.names || [] }
        break
      case 'project-created':
        bravin.bravinProject = String(m.name || '')
        break
    }
  })
  post('hello', { version: LMD_VERSION, bridge: BRIDGE_VERSION, features: ['context', 'new-project', 'sync-now'] })
  router.afterEach((to) => { updateContext(to) })
  router.isReady().then(() => updateContext(router.currentRoute.value))
}
