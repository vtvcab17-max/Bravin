<template>
  <div class="ai-config-content">
    <el-tabs v-model="activeTab" class="config-tabs">
      <el-tab-pane label="Cấu hình AI" name="configs">
        <div class="tab-content">
          <!-- 普通模式操作栏 -->
          <div v-if="!vendorLock.enabled" class="content-actions">
            <div class="actions-left">
              <el-button type="primary" @click="openAdd">
                <el-icon><Plus /></el-icon>
                Thêm cấu hình
              </el-button>
              <el-button plain @click="exportConfigs">
                <el-icon><Download /></el-icon>
                Xuất cấu hình
              </el-button>
              <el-button plain @click="triggerImport">
                <el-icon><Upload /></el-icon>
                Nhập cấu hình
              </el-button>
              <input ref="importFileRef" type="file" accept=".json" style="display:none" @change="importConfigs" />
              <el-button type="success" plain @click="openOneKeyVolc">
                <el-icon><MagicStick /></el-icon>
                Cấu hình nhanh Volcengine
              </el-button>
              <el-button type="success" plain @click="openOneKeyAgnes">
                <el-icon><MagicStick /></el-icon>
                Cấu hình nhanh Agnes
              </el-button>
              <el-button type="info" plain @click="openOneKeyTongyi">
                <el-icon><MagicStick /></el-icon>
                Cấu hình nhanh Tongyi
                <span class="one-key-not-recommended">Không khuyên dùng</span>
              </el-button>
              <el-button type="warning" plain @click="openOneKeyCheapSeedance2">
                <el-icon><MagicStick /></el-icon>
                Cấu hình nhanh Seedance2 giá rẻ
              </el-button>
            </div>
            <div class="actions-right">
              <transition name="fade-slide">
                <el-button
                  v-if="selectedRows.length > 0"
                  type="danger"
                  :loading="batchDeleting"
                  @click="onBatchDelete"
                >
                  <el-icon><Delete /></el-icon>
                  Xoá mục đã chọn ({{ selectedRows.length }})
                </el-button>
              </transition>
            </div>
          </div>
          <!-- 锁定模式提示栏 -->
          <div v-else class="vendor-lock-bar">
            <el-alert
              type="info"
              :closable="false"
              class="vendor-lock-tip"
            >
              <template #title>
                <span>🔒 Đang ở chế độ khoá nhà cung cấp, dịch vụ AI do quản trị viên cấu hình chung. Bạn chỉ sửa được <b>API Key</b> và <b>Model mặc định</b>。</span>
              </template>
            </el-alert>
            <el-button type="primary" size="small" class="vendor-bulk-key-btn" @click="openBulkKey">
              <el-icon><Key /></el-icon>
              Đổi Key nhanh
            </el-button>
          </div>
          <p class="default-tip">Mỗi loại dịch vụ chỉ có một cấu hình mặc định: Văn bản dùng để viết truyện; Văn bản tạo ảnh dùng cho ảnh nhân vật/bối cảnh/đạo cụ; Tạo ảnh phân cảnh dùng cho ảnh phân cảnh (hỗ trợ ảnh tham chiếu); Video dùng để tạo video; Tổng hợp giọng nói TTS dùng để lồng tiếng phân cảnh; Xác thực nhân vật Jimeng 2 dùng cho xác thực SD2 ở trang sáng tác (Token cổng); Kho tài sản SD2 dùng cho tài sản riêng ModelArk chính thức (dùng cho xác thực SD2 khi chưa cấu hình xác thực nhân vật Jimeng 2).</p>
          <el-table
            v-loading="loading"
            :data="list"
            stripe
            style="width: 100%"
            @selection-change="onSelectionChange"
          >
            <el-table-column v-if="!vendorLock.enabled" type="selection" width="46" />
            <el-table-column prop="name" label="Tên" min-width="130" />
            <el-table-column prop="provider" label="Nhà cung cấp" width="96" />
            <el-table-column prop="base_url" label="Base URL" min-width="170" show-overflow-tooltip />
            <el-table-column prop="default_model" label="Model mặc định" min-width="130" show-overflow-tooltip>
              <template #default="{ row }">
                {{ row.default_model || (Array.isArray(row.model) && row.model[0]) || '—' }}
              </template>
            </el-table-column>
            <el-table-column prop="service_type" label="Loại" width="148">
              <template #default="{ row }">
                <span :class="['type-badge', 'type-' + row.service_type]">
                  <el-icon class="type-icon">
                    <ChatDotRound v-if="row.service_type === 'text'" />
                    <Picture v-else-if="row.service_type === 'image'" />
                    <Film v-else-if="row.service_type === 'storyboard_image'" />
                    <VideoCamera v-else-if="row.service_type === 'video'" />
                    <Microphone v-else-if="row.service_type === 'tts'" />
                    <Key v-else-if="row.service_type === 'jimeng2_character_auth'" />
                    <Folder v-else-if="row.service_type === 'model_ark_asset'" />
                  </el-icon>
                  {{ serviceTypeLabel(row.service_type) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column prop="is_default" label="Mặc định" width="60">
              <template #default="{ row }">
                <el-tag v-if="row.is_default" type="success" size="small">✓</el-tag>
                <span v-else class="no-default">—</span>
              </template>
            </el-table-column>
            <el-table-column label="Thao tác" width="180" fixed="right">
              <template #default="{ row }">
                <el-button link type="primary" size="small" @click="openTest(row)">Kiểm tra</el-button>
                <el-button link type="primary" size="small" @click="onRowEdit(row)">{{ vendorLock.enabled ? 'Sửa Key' : 'Sửa' }}</el-button>
                <el-button v-if="!vendorLock.enabled" link type="danger" size="small" @click="onDelete(row)">Xoá</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-tab-pane>
      <el-tab-pane label="Cài đặt nâng cao (prompt)" name="prompts">
        <div class="tab-content">
          <PromptEditor />
        </div>
      </el-tab-pane>
      <el-tab-pane label="Cài đặt nâng cao (tình huống sử dụng)" name="sceneModelMap">
        <div class="tab-content">
          <SceneModelMap />
        </div>
      </el-tab-pane>
      <el-tab-pane label="Cài đặt tạo" name="generation">
        <div class="tab-content generation-settings">
          <div class="gs-section-title">⚡ Cài đặt chạy song song khi tạo một chạm</div>
          <p class="gs-desc">Điều khiển số tác vụ mỗi loại chạy song song trong quy trình «Tạo video một chạm» và «Bổ sung rồi tạo». Càng nhiều càng nhanh, nhưng quá cao có thể bị API giới hạn (lỗi 429). Nên chọn theo hạn mức API của bạn.</p>

          <div class="gs-row">
            <span class="gs-label">Số ảnh song song</span>
            <el-select
              v-model="genConcurrencyInput"
              filterable
              allow-create
              default-first-option
              placeholder="Chọn hoặc nhập số song song"
              style="width: 180px"
              @change="onConcurrencyChange"
            >
              <el-option label="1 (tuần tự, ổn định nhất)" :value="1" />
              <el-option label="2" :value="2" />
              <el-option label="3 (mặc định)" :value="3" />
              <el-option label="5" :value="5" />
              <el-option label="8" :value="8" />
              <el-option label="10" :value="10" />
            </el-select>
            <span class="gs-unit">tác vụ tạo cùng lúc</span>
          </div>

          <div class="gs-row" style="margin-top: 10px">
            <span class="gs-label">Số video song song</span>
            <el-select
              v-model="genVideoConcurrencyInput"
              filterable
              allow-create
              default-first-option
              placeholder="Chọn hoặc nhập số song song"
              style="width: 180px"
              @change="onVideoConcurrencyChange"
            >
              <el-option label="1 (tuần tự, ổn định nhất)" :value="1" />
              <el-option label="2" :value="2" />
              <el-option label="3 (mặc định)" :value="3" />
              <el-option label="5" :value="5" />
              <el-option label="8" :value="8" />
              <el-option label="10" :value="10" />
            </el-select>
            <span class="gs-unit">tác vụ tạo cùng lúc</span>
          </div>

          <div style="margin-top: 14px">
            <el-button
              type="primary"
              size="small"
              :loading="genSettingSaving"
              @click="saveGenerationSettings"
            >Lưu</el-button>
          </div>
          <el-alert
            v-if="genSettingSaved"
            type="success"
            title="Đã lưu"
            :closable="false"
            show-icon
            style="margin-top: 12px; width: fit-content"
          />
          <div class="gs-tip-box">
            <div class="gs-tip-title">📌 Phạm vi áp dụng</div>
            <ul class="gs-tip-list">
              <li>Song song ảnh: bước 2 ảnh nhân vật, bước 4 ảnh bối cảnh, bước 6 ảnh phân cảnh</li>
              <li>Song song video: bước 7 video phân cảnh</li>
            </ul>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="Quản lý tài sản SD2" name="sd2_assets">
        <div class="tab-content">
          <Sd2AssetManagement :configs="list" @saved="loadList" />
        </div>
      </el-tab-pane>
    </el-tabs>

    <!-- 添加/编辑 -->
    <el-dialog
      v-model="dialogVisible"
      :title="vendorLock.enabled ? 'Sửa API Key / model mặc định' : (editingId ? 'Sửa cấu hình' : 'Thêm cấu hình')"
      width="520px"
      :close-on-click-modal="false"
      @closed="resetForm"
    >
      <!-- 锁定模式：只展示 api_key 和 default_model -->
      <template v-if="vendorLock.enabled">
        <el-descriptions :column="1" border style="margin-bottom: 16px">
          <el-descriptions-item label="Tên">{{ form.name }}</el-descriptions-item>
          <el-descriptions-item label="Loại">{{ serviceTypeLabel(form.service_type) }}</el-descriptions-item>
          <el-descriptions-item label="Nhà cung cấp">{{ form.provider }}</el-descriptions-item>
        </el-descriptions>
        <el-form ref="formRef" :model="form" label-width="100px">
          <el-form-item prop="api_key" :rules="[{ required: true, message: 'Nhập API Key', trigger: 'blur' }]">
            <template #label><span class="form-label-tip">API Key</span></template>
            <el-input
              v-model="form.api_key"
              type="password"
              :placeholder="form.provider === 'jimeng_ai_api' ? 'Session Jimeng, nhiều session cách nhau bằng dấu phẩy' : 'Nhập khoá API của bạn'"
              show-password
            />
          </el-form-item>
          <el-form-item>
            <template #label><span class="form-label-tip">Model mặc định</span></template>
            <el-select v-model="form.default_model" clearable style="width: 100%">
              <el-option v-for="m in formModelList" :key="m" :label="m" :value="m" />
            </el-select>
            <p class="field-tip">Model dùng khi gọi thật, có thể chọn từ danh sách có sẵn.</p>
          </el-form-item>
          <el-form-item>
            <template #label>
              <span class="form-label-tip">Đặt làm mặc định
                <el-tooltip placement="top" popper-class="cfg-tip-popper">
                  <template #content>
                    <div class="cfg-tip-content">
                      Mỗi loại dịch vụ chỉ có một cấu hình «mặc định».<br>
                      Khi tạo, hệ thống ưu tiên cấu hình mặc định, nên đặt ít nhất một mặc định cho mỗi loại.
                    </div>
                  </template>
                  <el-icon class="tip-icon"><QuestionFilled /></el-icon>
                </el-tooltip>
              </span>
            </template>
            <el-switch v-model="form.is_default" />
          </el-form-item>
        </el-form>
      </template>

      <!-- 普通模式：完整表单 -->
      <el-form v-else ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item prop="service_type">
          <template #label>
            <span class="form-label-tip">Loại dịch vụ
              <el-tooltip placement="top" :show-arrow="true" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    <b>Văn bản/hội thoại</b>: dùng để AI viết kịch bản truyện<br>
                    <b>Văn bản tạo ảnh</b>: tạo ảnh nhân vật, bối cảnh, đạo cụ (không hỗ trợ ảnh tham chiếu)<br>
                    <b>Tạo ảnh phân cảnh</b>: tạo ảnh phân cảnh, hỗ trợ đưa vào ảnh tham chiếu nhân vật<br>
                    <b>Tạo video</b>: tạo đoạn video từ ảnh phân cảnh<br>
                    <b>Tổng hợp giọng nói TTS</b>: tự lồng tiếng lời thoại phân cảnh (dùng khi bấm nút lồng tiếng phân cảnh)<br>
                    <b>Xác thực nhân vật Jimeng 2</b>: đăng ký ảnh chính của nhân vật vào kho tư liệu Jimeng (xác thực SD2), chỉ cần URL cổng và Token
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-select v-model="form.service_type" placeholder="Chọn loại" style="width: 100%" @change="onServiceTypeChange">
            <el-option label="Văn bản/hội thoại" value="text" />
            <el-option label="Văn bản tạo ảnh" value="image" />
            <el-option label="Tạo ảnh phân cảnh" value="storyboard_image" />
            <el-option label="Tạo video" value="video" />
            <el-option label="Tổng hợp giọng nói TTS" value="tts" />
            <el-option label="Xác thực nhân vật Jimeng 2" value="jimeng2_character_auth" />
          </el-select>
        </el-form-item>
        <el-form-item prop="provider">
          <template #label>
            <span class="form-label-tip">Nhà cung cấp
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    Chọn nhà cung cấp có sẵn trong danh sách, Base URL và danh sách model sẽ tự điền.<br>
                    Cũng có thể nhập thẳng tên nhà cung cấp tuỳ chỉnh (phải tự điền các trường còn lại).<br>
                    <b>Khuyên dùng</b>: Tongyi Qianwen / Volcengine, truy cập ổn định từ Trung Quốc.
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-select
            v-model="form.provider"
            placeholder="Chọn nhà cung cấp có sẵn (tự điền URL và model)"
            clearable
            filterable
            allow-create
            default-first-option
            style="width: 100%"
            @change="onProviderChange"
          >
            <el-option
              v-for="p in availableProviderOptions"
              :key="p.id"
              :label="p.name"
              :value="p.id"
              :class="p.id === '__custom__' ? 'provider-custom-option' : ''"
            />
          </el-select>
        </el-form-item>
        <el-form-item v-if="form.service_type === 'video'">
          <template #label>
            <span class="form-label-tip">Toàn năng nhiều ảnh
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    Khi bật, phân cảnh chế độ toàn năng tạo video sẽ dùng nhiều ảnh tham chiếu (bối cảnh + nhân vật + đạo cụ), không còn hiện cảnh báo hạ cấp «model không khớp».<br>
                    «Seedance2 giá rẻ» bật sẵn; nhà cung cấp khác chỉ bật khi chắc chắn phía trên hỗ trợ tham chiếu nhiều ảnh.
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-switch
            v-model="form.supports_universal_omni"
            active-text="Xác nhận hỗ trợ chế độ toàn năng (tham chiếu nhiều ảnh)"
            inactive-text="Chưa xác nhận (toàn năng sẽ hạ cấp)"
          />
        </el-form-item>
        <el-alert
          v-if="form.provider === 'cheap_seedance2'"
          type="success"
          :closable="false"
          show-icon
          class="cheap-seedance2-tip"
        >
          <template #title>
            <span>
              Hợp để luyện tay và làm phim hàng loạt, giá rẻ, khoảng 1 tệ mỗi lần, không tính theo giây.
              Trang chủ:
              <a href="https://workbench.ohmybb.xyz/" target="_blank" rel="noopener noreferrer" class="cheap-seedance2-link">workbench.ohmybb.xyz</a>
            </span>
          </template>
        </el-alert>
        <!-- 接口规范：仅图片/分镜/视频类型显示，预设厂商自动填充；自定义厂商必选 -->
        <el-form-item v-if="form.service_type !== 'text' && form.service_type !== 'tts' && form.service_type !== 'jimeng2_character_auth'">
          <template #label>
            <span class="form-label-tip">Chuẩn API
              <el-icon class="tip-icon" style="cursor:pointer;color:#409eff" @click="showProtocolHelp = true"><QuestionFilled /></el-icon>
            </span>
          </template>
          <el-select v-model="form.api_protocol" style="width: 100%" placeholder="Chọn chuẩn API (bắt buộc với nhà cung cấp tuỳ chỉnh)" clearable>
            <el-option label="Tương thích OpenAI (mặc định của đa số trạm trung chuyển)" value="openai" />
            <el-option label="Volcengine (Doubao Seedream / Seedance)" value="volcengine" />
            <el-option label="Jimeng Seedance toàn năng của Volcengine (tham chiếu nhiều ảnh Ark, Seedance 2.0…)" value="volcengine_omni" />
            <el-option label="Tongyi Wanxiang DashScope" value="dashscope" />
            <el-option label="Google Gemini (ảnh / video Veo)" value="gemini" />
            <el-option label="Trạm trung chuyển Sora (multipart/form-data, seconds+size)" value="sora" />
            <el-option label="Tương thích Veo3 (JSON, images+enhance_prompt, tự dịch sang tiếng Anh)" value="veo3" />
            <el-option label="Video Vidu" value="vidu" />
            <el-option label="Kling Omni-Video (api-beijing chính thức / trung chuyển ffir, O1 toàn năng)" value="kling_omni" />
            <el-option label="xAI Grok Imagine (prompt + aspect_ratio chính thức, /v1/videos/generations)" value="xai" />
            <el-option label="MiniMax H3 (V2 chính thức: /v2/video_generation, model MiniMax-H3)" value="minimax_h3" />
            <el-option label="NanoBanana" value="nano_banana" />
          </el-select>
        </el-form-item>

        <!-- 接口规范帮助 Dialog -->
        <el-dialog v-model="showProtocolHelp" title="Giải thích chuẩn API" width="700px" top="5vh">
          <div class="protocol-help">
            <div class="ph-section-title">🖼 Giao thức ảnh / ảnh phân cảnh</div>
            <el-collapse accordion>
              <el-collapse-item name="openai-img">
                <template #title><span class="ph-tag ph-tag-img">Ảnh</span> Tương thích OpenAI — mặc định của đa số trạm trung chuyển</template>
                <div class="ph-body">
                  <b>Phù hợp với:</b>OpenAI chính thức, các trạm trung chuyển/proxy (ChatFire, SiliconFlow…)<br>
                  <b>Endpoint：</b><code>POST /v1/images/generations</code><br>
                  <pre>{ "model": "dall-e-3", "prompt": "...", "n": 1, "size": "1024x1024" }</pre>
                </div>
              </el-collapse-item>
              <el-collapse-item name="volcengine-img">
                <template #title><span class="ph-tag ph-tag-img">Ảnh</span> Volcengine — Doubao Seedream</template>
                <div class="ph-body">
                  <b>Endpoint：</b><code>POST /api/v3/images/generations</code><br>
                  <b>Base URL：</b><code>https://ark.cn-beijing.volces.com/api/v3</code><br>
                  <pre>{ "model": "doubao-seedream-4-5-251128", "prompt": "...", "size": "1024x1024" }</pre>
                </div>
              </el-collapse-item>
              <el-collapse-item name="dashscope-img">
                <template #title><span class="ph-tag ph-tag-img">Ảnh</span> Tongyi Wanxiang DashScope</template>
                <div class="ph-body">
                  <b>Base URL：</b><code>https://dashscope.aliyuncs.com</code><br>
                  <b>Endpoint：</b><code>POST /api/v1/services/aigc/text2image/image-synthesis</code>
                </div>
              </el-collapse-item>
              <el-collapse-item name="gemini-img">
                <template #title><span class="ph-tag ph-tag-img">Ảnh</span> Google Gemini</template>
                <div class="ph-body">
                  <b>Xác thực:</b>Tham số URL <code>?key=API_KEY</code><br>
                  <b>Endpoint：</b><code>POST /v1beta/models/{model}:generateContent</code>
                </div>
              </el-collapse-item>
            </el-collapse>

            <div class="ph-section-title" style="margin-top:16px">🎬 Giao thức video</div>
            <el-collapse accordion>
              <el-collapse-item name="cheap-seedance2-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Seedance2 giá rẻ — tương thích Sora (ohmybb)</template>
                <div class="ph-body">
                  <b>Phù hợp với:</b>Luyện tay, làm phim hàng loạt; tính tiền theo lượt (khoảng 1 tệ/lượt), không tính theo giây.<br>
                  <b>Nhà cung cấp:</b>Chọn «Seedance2 giá rẻ» là tự điền Base URL / giao thức / model, và bật sẵn «Xác nhận hỗ trợ chế độ toàn năng».<br>
                  <b>Base URL：</b><code>https://workbench.ohmybb.xyz/api/openai</code><br>
                  <b>Chuẩn API:</b><code>sora</code>(multipart/form-data; khi tham chiếu nhiều ảnh dùng JSON <code>images</code> mảng, tối đa 9 ảnh)<br>
                  <b>Endpoint mặc định:</b><code>POST /v1/videos</code>, truy vấn <code>GET /v1/videos/{taskId}</code>; tải thành phẩm phải kèm Key <code>/v1/videos/{id}/content</code>(hệ thống tự xử lý).<br>
                  <b>Model:</b><code>wb-seedance-2-fast</code>(5/10/15 giây),<code>wb-seedance-2.5</code>(5/10 giây)<br>
                  <b>Trang chủ / nạp tiền:</b><a href="https://workbench.ohmybb.xyz/" target="_blank" rel="noopener noreferrer">https://workbench.ohmybb.xyz/</a>
                </div>
              </el-collapse-item>
              <el-collapse-item name="openai-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Tương thích OpenAI — định dạng mảng content</template>
                <div class="ph-body">
                  <b>Phù hợp với:</b>API video của các trạm trung chuyển (ChatFire…)<br>
                  <b>Endpoint：</b>Tuỳ chỉnh, ví dụ <code>POST /v1/video/create</code><br>
                  <pre>{ "model": "sora-2-pro",
  "content": [
    { "type": "text", "text": "..." },
    { "type": "image_url", "image_url": { "url": "https://..." }, "role": "reference_image" }
  ],
  "ratio": "9:16", "duration": 5, "watermark": false, "resolution": "720p" }</pre>
                </div>
              </el-collapse-item>
              <el-collapse-item name="sora-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Trạm trung chuyển Sora — multipart/form-data</template>
                <div class="ph-body">
                  <b>Phù hợp với:</b>Trạm trung chuyển theo định dạng Sora API<br>
                  <b>Endpoint mặc định:</b><code>POST /v1/videos</code>(tạo),<code>GET /v1/videos/{taskId}</code>(truy vấn)<br>
                  <b>Định dạng yêu cầu:</b>multipart/form-data (không phải JSON)<br>
                  <pre>model       = "sora-2"
prompt      = "..."
seconds     = "4" | "8" | "12"
size        = "720x1280" | "1280x720" | "1024x1792" | "1792x1024"
watermark   = "false"
private     = "false"
input_reference = (tệp ảnh, tuỳ chọn)</pre>
                  <b>Lưu ý:</b>Ảnh tham chiếu sẽ tự đổi kích thước cho khớp size rồi mới tải lên.
                </div>
              </el-collapse-item>
              <el-collapse-item name="veo3-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Tương thích Veo3 — images + enhance_prompt</template>
                <div class="ph-body">
                  <b>Phù hợp với:</b>API định dạng JSON của dòng model Veo3<br>
                  <b>Endpoint mặc định:</b><code>POST /v1/video/create</code>(tạo),<code>GET /v1/video/query?id={taskId}</code>(truy vấn)<br>
                  <pre>{ "model": "veo3.1",
  "prompt": "...",
  "enhance_prompt": true,
  "images": ["data:image/jpeg;base64,..."]
}</pre>
                  <b>Lưu ý:</b><code>enhance_prompt: true</code> sẽ khiến API tự dịch prompt sang tiếng Anh. Ảnh localhost được tự chuyển sang base64 nhúng.
                </div>
              </el-collapse-item>
              <el-collapse-item name="volcengine-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Volcengine — Doubao Seedance</template>
                <div class="ph-body">
                  <b>Endpoint：</b><code>POST …/contents/generations/tasks</code>(giống phía máy chủ)<br>
                  <b>Base URL：</b><code>https://ark.cn-beijing.volces.com/api/v3</code><br>
                  <pre>{ "model": "doubao-seedance-1-5-pro-251215",
  "content": [{ "type": "text", "text": "..." }],
  "ratio": "9:16", "duration": 5,
  "watermark": false, "resolution": "720p" }</pre>
                </div>
              </el-collapse-item>
              <el-collapse-item name="volcengine-omni-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Jimeng Seedance toàn năng của Volcengine (tham chiếu nhiều ảnh)</template>
                <div class="ph-body">
                  <b>Dùng cho:</b>luồng toàn năng hỗ trợ nhiều ảnh tham chiếu như Ark Seedance 2.0; dùng cùng phân cảnh «chế độ toàn năng»,<code>@图片1</code>… prompt.<br>
                  <b>Endpoint：</b><code>POST {base}/contents/generations/tasks</code>, theo dõi <code>GET {base}/contents/generations/tasks/{taskId}</code><br>
                  <b>Nhà cung cấp:</b>vẫn chọn «Volcengine»,<b>Chuẩn API</b>chọn mục này; model điền điểm truy cập trên bảng điều khiển (ví dụ <code>doubao-seedance-2-0-260128</code>, theo bảng điều khiển).<br>
                  <pre>{ "model": "doubao-seedance-2-0-260128",
  "task_type": "i2v",
  "content": [
    { "type": "text", "text": "… @图片1 … @图片2 …" },
    { "type": "image_url", "image_url": { "url": "https://..." } },
    { "type": "image_url", "image_url": { "url": "https://..." }, "role": "reference_image" }
  ],
  "ratio": "9:16", "duration": 8, "watermark": false }</pre>
                  <b>Giải thích:</b>Ở chế độ toàn năng, mọi ảnh dưới đây đều là ảnh tham chiếu (bối cảnh, nhân vật…), mỗi ảnh đều <code>role: reference_image</code>; tối đa 9 ảnh, thời lượng Seedance 2.x làm tròn theo 4–15 giây.
                </div>
              </el-collapse-item>
              <el-collapse-item name="dashscope-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Tongyi Wanxiang DashScope</template>
                <div class="ph-body">
                  <b>Base URL：</b><code>https://dashscope.aliyuncs.com</code><br>
                  <b>Endpoint：</b><code>POST /api/v1/services/aigc/video-generation/video-synthesis</code><br>
                  <pre>{ "model": "wan2.2-kf2v-flash",
  "input": { "prompt": "...", "img_url": "https://..." },
  "parameters": { "size": "1280*720", "duration": 5 } }</pre>
                </div>
              </el-collapse-item>
              <el-collapse-item name="gemini-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Google Gemini — video Veo</template>
                <div class="ph-body">
                  <b>Xác thực:</b>Tham số URL <code>?key=API_KEY</code><br>
                  <b>Endpoint：</b><code>POST /v1beta/models/{model}:generateVideo</code>
                </div>
              </el-collapse-item>
              <el-collapse-item name="vidu-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Vidu</template>
                <div class="ph-body">
                  <b>Phù hợp với:</b>API Vidu chính thức và tương thích<br>
                  <b>Xác thực:</b><code>Authorization: Token {api_key}</code>(không phải Bearer)<br>
                  <b>Endpoint mặc định:</b><code>POST /ent/v2/img2video</code>(tạo),<code>GET /ent/v2/tasks/{taskId}/creations</code>(truy vấn)<br>
                  <pre>{ "model": "viduq3-pro",
  "images": ["https://..."],
  "prompt": "...",
  "duration": 5,
  "resolution": "720p",
  "movement_amplitude": "auto",
  "audio": false,
  "watermark": false
}</pre>
                  <b>Lưu ý:</b>api.vidu.cn chính thức dùng <code>Token</code> xác thực, trạm trung chuyển dùng <code>Bearer</code>, hệ thống tự nhận biết. Ảnh localhost được tự tải lên dịch vụ lưu ảnh.
                </div>
              </el-collapse-item>
              <el-collapse-item name="jimeng-ai-api-vid">
                <template #title><span class="ph-tag ph-tag-vid">Video</span> Jimeng AI API (tự dựng)</template>
                <div class="ph-body">
                  <b>Giải thích:</b>Cần tự triển khai <code>jimeng-free-api-all</code> dịch vụ Jimeng tương thích OpenAI và khởi động (ví dụ <code>http://127.0.0.1:8000</code>). Hệ thống này chỉ là bên gửi yêu cầu.<br>
                  <b>Base URL：</b>Điền địa chỉ gốc dịch vụ của bạn, không có dấu gạch chéo cuối.<br>
                  <b>API Key：</b>Điền trên web Jimeng <b>Session</b>; nhiều tài khoản cách nhau bằng<b>dấu phẩy</b>, dịch vụ kia sẽ dùng lần lượt.<br>
                  <b>Đường dẫn mặc định:</b><code>POST /v1/videos/generations</code>(có thể ghi đè ở «Endpoint»). Seedance nhiều ảnh cần ảnh tham chiếu phân cảnh; phản hồi là đồng bộ <code>data[0].url</code>。
                </div>
              </el-collapse-item>
            </el-collapse>
          </div>
          <template #footer>
            <el-button @click="showProtocolHelp = false">Đóng</el-button>
          </template>
        </el-dialog>
        <el-form-item prop="name">
          <template #label>
            <span class="form-label-tip">Tên
              <el-tooltip content="Tên hiển thị của cấu hình, để phân biệt trong danh sách; tự tạo sau khi chọn nhà cung cấp." placement="top" popper-class="cfg-tip-popper">
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-input v-model="form.name" placeholder="Ví dụ: OpenAI ảnh-chữ, có thể tự tạo" />
        </el-form-item>
        <el-form-item prop="base_url">
          <template #label>
            <span class="form-label-tip">{{ form.service_type === 'jimeng2_character_auth' ? 'URL cổng' : 'Base URL' }}
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    <template v-if="form.service_type === 'jimeng2_character_auth'">
                      của cổng kho tư liệu Jimeng<b>địa chỉ gốc</b>(không gồm <code>/api/business/v1</code> đường dẫn). Phải khớp với nơi kho tư liệu đang chạy.
                    </template>
                    <template v-else>
                      Địa chỉ API, tự điền khi chọn nhà cung cấp có sẵn, thường không cần sửa.<br>
                      Ví dụ: https://dashscope.aliyuncs.com
                    </template>
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-input
            v-model="form.base_url"
            :placeholder="form.service_type === 'jimeng2_character_auth' ? 'Ví dụ https://your-gateway.com' : 'Tự điền khi chọn nhà cung cấp, có thể sửa'"
          />
        </el-form-item>
        <el-form-item prop="api_key">
          <template #label>
            <span class="form-label-tip">{{ form.service_type === 'jimeng2_character_auth' ? 'Token' : 'API Key' }}
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    <template v-if="form.service_type === 'jimeng2_character_auth'">
                      kho tư liệu yêu cầu <code>Authorization: Bearer …</code> Token, do cổng hoặc phía Jimeng cấp.
                    </template>
                    <template v-else>
                      Khoá đăng ký trên nền tảng AI tương ứng, dùng để xác thực.<br>
                      Tongyi:<b>dashscope.aliyuncs.com</b><br>
                      Volcengine:<b>console.volcengine.com/ark</b>
                    </template>
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-input
            v-model="form.api_key"
            type="password"
            :placeholder="form.service_type === 'jimeng2_character_auth' ? 'Bearer Token' : (form.provider === 'jimeng_ai_api' ? 'Session Jimeng, nhiều session cách nhau bằng dấu phẩy' : 'Khoá API')"
            show-password
          />
        </el-form-item>
        <el-form-item v-if="form.service_type === 'jimeng2_character_auth'">
          <template #label><span class="form-label-tip">Danh sách tư liệu</span></template>
          <div class="jimeng2-assets-actions">
            <el-button type="primary" plain :loading="jimeng2AssetsLoading" @click="openJimeng2MaterialAssetsDialog">
              Liệt kê tư liệu
            </el-button>
            <span class="field-tip jimeng2-assets-tip">
              Gọi cổng
              <code>GET /api/business/v1/assets</code>
              , giống
              <a href="https://83zi.com/sd2realperson.html" target="_blank" rel="noopener noreferrer">tài liệu API quản lý tư liệu</a>
              (dùng URL cổng và Token đang có trong biểu mẫu, không cần lưu trước).
            </span>
          </div>
        </el-form-item>
        <el-alert
          v-if="form.service_type === 'jimeng2_character_auth'"
          type="info"
          :closable="false"
          show-icon
          style="margin-bottom: 12px"
          title="Dùng cho «Tạo nhân vật → xác thực SD2» ở trang sáng tác"
          description="Sau khi lưu, hệ thống đọc cổng và Token ở đây để gọi POST /api/business/v1/assets đăng ký ảnh nhân vật; dùng «Liệt kê tư liệu» để đối chiếu trạng thái. Ảnh chính của nhân vật phải là địa chỉ http(s) truy cập được từ Internet (dịch vụ lưu ảnh hoặc storage.base_url của máy chủ này)."
        />
        <template v-if="form.service_type === 'video' && form.api_protocol === 'kling_omni'">
          <el-form-item>
            <template #label><span class="form-label-tip">AccessKey</span></template>
            <el-input
              v-model="form.kling_access_key"
              type="password"
              show-password
              placeholder="AccessKey nền tảng mở Kling (đi cặp với SecretKey, có thể để trống API Key ở trên)"
              autocomplete="off"
            />
            <p class="field-tip">
              Quy tắc JWT chính thức xem
              <a href="https://klingai.com/document-api/apiReference/commonInfo" target="_blank" rel="noopener noreferrer">commonInfo</a>
              （<a href="https://app.klingai.com/cn/dev/document-api/apiReference/commonInfo" target="_blank" rel="noopener noreferrer">bản tiếng Trung</a>）。
              Máy chủ dùng HS256 giống ví dụ chính thức (<code>iss</code>=AccessKey，<code>exp</code>、<code>nbf</code>) để tạo Token.
              Nếu API trả về <code>1000 Authorization signature is invalid</code>: kiểm tra AccessKey/SecretKey không bị điền ngược, không thừa khoảng trắng; thử bật «SecretKey là Base64» bên dưới;
              Khu vực Base URL (<code>api-beijing.klingai.com</code> / <code>api-singapore.klingai.com</code>) phải trùng khu vực của khoá.
            </p>
          </el-form-item>
          <el-form-item>
            <template #label><span class="form-label-tip">SecretKey</span></template>
            <el-input
              v-model="form.kling_secret_key"
              type="password"
              show-password
              placeholder="SecretKey nền tảng mở Kling"
              autocomplete="off"
            />
            <el-checkbox v-model="form.kling_secret_key_base64" style="margin-top: 8px; display: block">
              SecretKey là chuỗi Base64 (giải mã ra nhị phân rồi mới ký; nếu vẫn báo chữ ký sai thì đổi mục này rồi thử lại)
            </el-checkbox>
            <p class="field-tip">
              Tên miền chính thức:<code>POST {base}/v1/videos/omni-video</code>, theo dõi
              <code>GET {base}/v1/videos/omni-video/{taskId}</code>; các trạm trung chuyển như Feier vẫn là
              <code>/kling/v1/videos/omni-video</code> và
              <code>/kling/v1/images/omni-image/{taskId}</code>. Xem chi tiết
              <a href="https://klingai.com/document-api/apiReference/model/OmniVideo" target="_blank" rel="noopener noreferrer">OmniVideo</a>。
            </p>
          </el-form-item>
        </template>
        <!-- TTS 专属字段：声音 ID 和 MiniMax Group ID -->
        <template v-if="form.service_type === 'tts'">
          <el-form-item>
            <template #label>
              <span class="form-label-tip">ID giọng
                <el-tooltip placement="top" popper-class="cfg-tip-popper">
                  <template #content>
                    <div class="cfg-tip-content">
                      ID giọng đọc dùng khi tổng hợp TTS.<br>
                      <b>Giọng MiniMax hay dùng:</b><br>
                      female-shaonv (thiếu nữ), female-chengshu (trưởng thành)<br>
                      male-qingxin (nam trong trẻo), male-zhicheng (nam Zhicheng)<br>
                      audiobook_female_2 (nữ đọc sách), audiobook_male_1 (nam đọc sách)
                    </div>
                  </template>
                  <el-icon class="tip-icon"><QuestionFilled /></el-icon>
                </el-tooltip>
              </span>
            </template>
            <el-select
              v-model="form.voice_id"
              filterable
              allow-create
              default-first-option
              placeholder="Chọn hoặc nhập ID giọng"
              style="width: 100%"
            >
              <el-option-group label="Giọng nữ MiniMax">
                <el-option label="female-shaonv (thiếu nữ)" value="female-shaonv" />
                <el-option label="female-chengshu (trưởng thành)" value="female-chengshu" />
                <el-option label="female-tianmei (ngọt ngào)" value="female-tianmei" />
                <el-option label="audiobook_female_2 (đọc sách)" value="audiobook_female_2" />
              </el-option-group>
              <el-option-group label="Giọng nam MiniMax">
                <el-option label="male-qingxin (trong trẻo)" value="male-qingxin" />
                <el-option label="male-zhicheng (Zhicheng)" value="male-zhicheng" />
                <el-option label="audiobook_male_1 (đọc sách)" value="audiobook_male_1" />
              </el-option-group>
            </el-select>
            <p class="field-tip">Bắt buộc với MiniMax; để trống thì mặc định female-shaonv.</p>
          </el-form-item>
          <el-form-item>
            <template #label>
              <span class="form-label-tip">Group ID
                <el-tooltip placement="top" popper-class="cfg-tip-popper">
                  <template #content>
                    <div class="cfg-tip-content">
                      GroupId của tài khoản MiniMax, gắn vào tham số URL khi gọi API T2A v2.<br>
                      Đăng nhập <b>platform.minimaxi.com</b> → Cài đặt tài khoản → là thấy GroupId.
                    </div>
                  </template>
                  <el-icon class="tip-icon"><QuestionFilled /></el-icon>
                </el-tooltip>
              </span>
            </template>
            <el-input v-model="form.group_id" placeholder="MiniMax GroupId, ví dụ 1234567890" />
            <p class="field-tip">Chỉ MiniMax T2A cần trường này.</p>
          </el-form-item>
        </template>

        <!-- 端点配置：视频必填（自定义厂商）；图片/分镜在使用代理或特殊厂商时填写 -->
        <template v-if="form.service_type !== 'text' && form.service_type !== 'tts' && form.service_type !== 'jimeng2_character_auth'">
          <el-form-item>
            <template #label>
              <span class="form-label-tip">Endpoint gửi
                <el-tooltip placement="top" popper-class="cfg-tip-popper">
                  <template #content>
                    <div class="cfg-tip-content">
                      Đường dẫn API, nối sau Base URL.<br>
                      <b>Nhà cung cấp có sẵn</b>(Volcengine / Tongyi / NanoBanana) để trống, hệ thống tự suy ra.<br>
                      <b>Nhà cung cấp video tuỳ chỉnh</b>bắt buộc điền, ví dụ /v1/videos/generations<br>
                      <b>Proxy NanoBanana</b>điền đường dẫn proxy, ví dụ /fal-ai/nano-banana
                    </div>
                  </template>
                  <el-icon class="tip-icon"><QuestionFilled /></el-icon>
                </el-tooltip>
              </span>
            </template>
            <el-input v-model="form.endpoint" :placeholder="form.service_type === 'video' ? 'Bắt buộc với nhà cung cấp video tuỳ chỉnh, ví dụ /v1/videos/generations; nhà cung cấp có sẵn thì để trống' : 'Điền khi dùng proxy hoặc nhà cung cấp đặc biệt, ví dụ /fal-ai/nano-banana; nhà cung cấp có sẵn thì để trống'" />
          </el-form-item>
          <el-form-item>
            <template #label>
              <span class="form-label-tip">Endpoint truy vấn
                <el-tooltip placement="top" popper-class="cfg-tip-popper">
                  <template #content>
                    <div class="cfg-tip-content">
                      Đường dẫn API để hỏi trạng thái tác vụ,{taskId} sẽ được thay bằng ID tác vụ thật.<br>
                      <b>Nhà cung cấp có sẵn</b>Để trống, hệ thống tự suy ra.<br>
                      <b>Nhà cung cấp video tuỳ chỉnh</b>bắt buộc điền, ví dụ /v1/video/tasks/{taskId}<br>
                      <b>Ảnh/NanoBanana</b> proxy không hỗ trợ theo dõi thì để trống
                    </div>
                  </template>
                  <el-icon class="tip-icon"><QuestionFilled /></el-icon>
                </el-tooltip>
              </span>
            </template>
            <el-input v-model="form.query_endpoint" placeholder="Bắt buộc với nhà cung cấp video tuỳ chỉnh, ví dụ /v1/video/tasks/{taskId}; nhà cung cấp có sẵn thì để trống" />
          </el-form-item>
        </template>

        <!-- 接口地址预览：选择厂商/协议后自动展示，帮助用户核对 -->
        <div v-if="endpointPreviewInfo" class="endpoint-preview-box" :class="{ 'ep-box-gemini': endpointPreviewInfo.isGemini }">
          <div class="ep-preview-header">
            <span>📌 Hệ thống sẽ dùng các địa chỉ API sau</span>
            <span v-if="endpointPreviewInfo.isGemini" class="ep-auto-badge ep-badge-gemini">Chế độ cố định của Gemini</span>
            <span v-else-if="endpointPreviewInfo.isJimeng2Auth" class="ep-auto-badge">Xác thực nhân vật Jimeng 2</span>
            <span v-else-if="endpointPreviewInfo.isAuto && form.service_type !== 'text'" class="ep-auto-badge">Tự suy ra</span>
          </div>
          <div class="ep-row">
            <span class="ep-label">Địa chỉ gửi:</span>
            <code class="ep-url">{{ endpointPreviewInfo.submit }}</code>
          </div>
          <div v-if="endpointPreviewInfo.query" class="ep-row">
            <span class="ep-label">Địa chỉ truy vấn:</span>
            <code class="ep-url">{{ endpointPreviewInfo.query }}</code>
          </div>
          <p v-if="endpointPreviewInfo.isGemini" class="ep-tip ep-tip-warn">
            ⚠️ Endpoint Gemini do hệ thống tạo cố định theo tên model; trường «Endpoint gửi» và «Endpoint truy vấn» ở trên không có tác dụng với Gemini.
          </p>
          <p v-else-if="endpointPreviewInfo.isJimeng2Auth" class="ep-tip">«Xác thực SD2» của nhân vật sẽ gọi địa chỉ trên để đăng ký tư liệu (POST tạo, GET hỏi trạng thái).</p>
          <p v-else class="ep-tip">Trên đây là địa chỉ thật hệ thống suy ra (có thể điền tay các trường endpoint ở trên để ghi đè)</p>
        </div>

        <template v-if="form.service_type !== 'jimeng2_character_auth'">
        <el-form-item>
          <template #label>
            <span class="form-label-tip">Danh sách model
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    Các model dùng được của nhà cung cấp này, cách nhau bằng dấu phẩy hoặc xuống dòng.<br>
                    Có thể thêm nhanh từ «Thêm model có sẵn» ở trên, hoặc nhập tay.
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <div class="model-row">
            <el-select
              v-model="presetModelPick"
              placeholder="Thêm model có sẵn"
              clearable
              filterable
              style="width: 220px; margin-bottom: 8px"
              @change="onPresetModelSelect"
            >
              <el-option v-for="m in availableModels" :key="m" :label="m" :value="m" />
            </el-select>
          </div>
          <el-input v-model="form.modelText" type="textarea" :rows="2" placeholder="Tự điền khi chọn nhà cung cấp, sửa được; nhiều model cách nhau bằng dấu phẩy hoặc xuống dòng" />
        </el-form-item>
        <el-form-item>
          <template #label>
            <span class="form-label-tip">Model mặc định
              <el-tooltip content="Khi có nhiều model, đây là model thật sự được gọi để tạo. Nên chọn model nhanh và cho kết quả tốt." placement="top" popper-class="cfg-tip-popper">
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-select
            v-model="form.default_model"
            :placeholder="formModelList.length ? 'Chọn một model trong danh sách trên làm mặc định khi tạo' : 'Hãy điền danh sách model ở trên trước'"
            clearable
            style="width: 100%"
          >
            <el-option v-for="m in formModelList" :key="m" :label="m" :value="m" />
          </el-select>
          <p class="field-tip">Khi cấu hình này là «mặc định», tạo truyện/ảnh/video sẽ dùng model chỉ định ở đây.</p>
        </el-form-item>
        <el-form-item v-if="isDeepSeekOfficialForm">
          <template #label>
            <span class="form-label-tip">Chế độ suy nghĩ
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    Model chính thức DeepSeek V4 dùng tham số thinking để bật/tắt suy nghĩ.<br>
                    Tắt suy nghĩ tương ứng deepseek-chat cũ; bật suy nghĩ tương ứng deepseek-reasoner cũ.
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <div class="deepseek-settings">
            <el-radio-group v-model="form.deepseek_thinking">
              <el-radio-button label="disabled">Tắt suy nghĩ</el-radio-button>
              <el-radio-button label="enabled">Bật suy nghĩ</el-radio-button>
            </el-radio-group>
            <el-select
              v-if="form.deepseek_thinking === 'enabled'"
              v-model="form.deepseek_reasoning_effort"
              style="width: 140px"
            >
              <el-option label="high" value="high" />
              <el-option label="max" value="max" />
            </el-select>
          </div>
          <p class="field-tip">Tên model cũ chính thức sẽ ngừng dùng từ 2026-07-24; cấu hình mới nên dùng deepseek-v4-flash hoặc deepseek-v4-pro.</p>
        </el-form-item>
        </template>
        <el-form-item>
          <template #label>
            <span class="form-label-tip">Độ ưu tiên
              <el-tooltip content="Khi một loại dịch vụ có nhiều cấu hình, số càng lớn càng được gọi trước. Mặc định 0, thường đặt 10 là được." placement="top" popper-class="cfg-tip-popper">
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-input-number v-model="form.priority" :min="0" :max="999" />
        </el-form-item>
        <el-form-item>
          <template #label>
            <span class="form-label-tip">Đặt làm mặc định
              <el-tooltip placement="top" popper-class="cfg-tip-popper">
                <template #content>
                  <div class="cfg-tip-content">
                    Mỗi loại dịch vụ chỉ có một cấu hình «mặc định».<br>
                    Khi tạo, hệ thống ưu tiên cấu hình mặc định, nên đặt ít nhất một mặc định cho mỗi loại.
                  </div>
                </template>
                <el-icon class="tip-icon"><QuestionFilled /></el-icon>
              </el-tooltip>
            </span>
          </template>
          <el-switch v-model="form.is_default" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">Huỷ</el-button>
        <el-button type="primary" :loading="saving" @click="submit">Đồng ý</el-button>
      </template>
    </el-dialog>

    <!-- 一键配置低价 Seedance2 -->
    <el-dialog
      v-model="oneKeyCheapSeedance2Visible"
      title="Cấu hình nhanh Seedance2 giá rẻ"
      width="520px"
      :close-on-click-modal="false"
      @closed="oneKeyCheapSeedance2Key = ''"
    >
      <div class="one-key-help">
        <div class="one-key-section">
          <div class="one-key-section-title">📋 Sẽ tự tạo các cấu hình sau</div>
          <ul class="one-key-list">
            <li><b>Tạo video</b>: Seedance2 giá rẻ (wb-seedance-2-fast / wb-seedance-2.5) — luyện tay và làm phim hàng loạt, khoảng 1 tệ/lượt, không tính theo giây</li>
          </ul>
          <p class="one-key-note">sẽ được đặt làm cấu hình mặc định cho dịch vụ video; Base URL / giao thức / endpoint tự điền.</p>
        </div>
        <div class="one-key-section">
          <div class="one-key-section-title">🔑 Cách đăng ký API Key</div>
          <ol class="one-key-list">
            <li>Mở trang chủ:<a href="https://workbench.ohmybb.xyz/" target="_blank" rel="noopener noreferrer" class="one-key-link">workbench.ohmybb.xyz</a></li>
            <li>Sau khi đăng nhập, vào «API Keys» ở cuối thanh bên trái, tạo khoá (định dạng:<code>vw_xxxxxxxx</code>）</li>
            <li>Khoá chỉ hiện một lần lúc tạo, hãy lưu cẩn thận rồi điền xuống dưới</li>
          </ol>
          <p class="one-key-note">💡 Tài liệu API:<a href="https://workbench.ohmybb.xyz/docs/api" target="_blank" rel="noopener noreferrer" class="one-key-link">workbench.ohmybb.xyz/docs/api</a></p>
        </div>
      </div>
      <el-form label-width="0" style="margin-top: 8px">
        <el-form-item>
          <el-input
            v-model="oneKeyCheapSeedance2Key"
            type="password"
            placeholder="Nhập API Key, định dạng: vw_xxxxxxxx"
            show-password-on="click"
            clearable
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="oneKeyCheapSeedance2Visible = false">Huỷ</el-button>
        <el-button type="success" :loading="oneKeyCheapSeedance2Saving" :disabled="!oneKeyCheapSeedance2Key.trim()" @click="submitOneKeyCheapSeedance2">
          Đồng ý, tạo cấu hình một chạm
        </el-button>
      </template>
    </el-dialog>

    <!-- 一键配置通义 -->
    <el-dialog
      v-model="oneKeyTongyiVisible"
      title="Cấu hình nhanh Tongyi Qianwen / Wanxiang (không khuyên dùng)"
      width="520px"
      :close-on-click-modal="false"
      @closed="oneKeyTongyiKey = ''"
    >
      <div class="one-key-help">
        <div class="one-key-section">
          <div class="one-key-section-title">📋 Sẽ tự tạo các cấu hình sau</div>
          <ul class="one-key-list">
            <li><b>Văn bản/hội thoại</b>: Tongyi Qianwen (qwen-plus) — viết kịch bản</li>
            <li><b>Văn bản tạo ảnh</b>: Tongyi Wanxiang (wan2.6-image) — ảnh nhân vật/bối cảnh/đạo cụ</li>
            <li><b>Văn bản tạo ảnh</b>: Tongyi Qianwen Image (qwen-image-max) — ảnh nhân vật/bối cảnh dự phòng</li>
            <li><b>Tạo ảnh phân cảnh</b>: Tongyi Wanxiang (wan2.6-image) — hỗ trợ ảnh tham chiếu nhân vật</li>
            <li><b>Tạo video</b>: Tongyi Wanxiang (wan2.2-kf2v-flash) — tạo đoạn video</li>
          </ul>
        </div>
        <div class="one-key-section">
          <div class="one-key-section-title">🔑 Cách đăng ký API Key</div>
          <ol class="one-key-list">
            <li>Vào bảng điều khiển Alibaba Cloud Bailian:<a href="https://bailian.console.aliyun.com/" target="_blank" class="one-key-link">bailian.console.aliyun.com</a></li>
            <li>Đăng ký/đăng nhập tài khoản Alibaba Cloud, mở dịch vụ «Bailian» (người dùng mới có hạn mức miễn phí)</li>
            <li>Ở menu trái bấm «API Key» → «Tạo API Key»</li>
            <li>Sao chép Key vừa tạo (định dạng:<code>sk-xxxxxxxx</code>) rồi điền xuống dưới</li>
          </ol>
          <p class="one-key-note">💡 Một Key Tongyi dùng được cho mọi dịch vụ: văn bản, ảnh, video</p>
        </div>
      </div>
      <el-form label-width="0" style="margin-top: 8px">
        <el-form-item>
          <el-input
            v-model="oneKeyTongyiKey"
            type="password"
            placeholder="Nhập API Key Tongyi (DashScope), định dạng: sk-xxxxxxxx"
            show-password-on="click"
            clearable
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="oneKeyTongyiVisible = false">Huỷ</el-button>
        <el-button type="success" :loading="oneKeyTongyiSaving" :disabled="!oneKeyTongyiKey.trim()" @click="submitOneKeyTongyi">
          Đồng ý, tạo cấu hình một chạm
        </el-button>
      </template>
    </el-dialog>

    <!-- 一键配置火山 -->
    <el-dialog
      v-model="oneKeyVolcVisible"
      title="Cấu hình nhanh Volcengine (Ark)"
      width="520px"
      :close-on-click-modal="false"
      @closed="oneKeyVolcKey = ''"
    >
      <div class="one-key-help">
        <div class="one-key-section">
          <div class="one-key-section-title">📋 Sẽ tự tạo các cấu hình sau</div>
          <ul class="one-key-list">
            <li><b>Văn bản/hội thoại</b>: DeepSeek V3 (deepseek-v3-2-251201) — viết kịch bản</li>
            <li><b>Văn bản tạo ảnh</b>: Jimeng 4.5 (doubao-seedream-4-5-251128) — ảnh nhân vật/bối cảnh/đạo cụ</li>
            <li><b>Tạo ảnh phân cảnh</b>: Jimeng 4.5 (doubao-seedream-4-5-251128) — hỗ trợ ảnh tham chiếu nhân vật</li>
            <li><b>Tạo video</b>: Jimeng Seedance 1.5 Pro — tạo đoạn video</li>
          </ul>
        </div>
        <div class="one-key-section">
          <div class="one-key-section-title">🔑 Cách đăng ký API Key</div>
          <ol class="one-key-list">
            <li>Vào bảng điều khiển Volcengine Ark:<a href="https://console.volcengine.com/ark" target="_blank" class="one-key-link">console.volcengine.com/ark</a></li>
            <li>Đăng ký/đăng nhập tài khoản Volcengine của ByteDance (người dùng mới có hạn mức token miễn phí)</li>
            <li>Ở menu trái bấm «Quản lý API Key» → «Tạo API Key»</li>
            <li>Sao chép Key vừa tạo rồi điền xuống dưới</li>
          </ol>
          <p class="one-key-note">💡 Một Key nền tảng Ark dùng được cho văn bản Doubao, ảnh và video Jimeng…</p>
          <p class="one-key-note">⚠️ Muốn tạo video phải «kích hoạt» model tương ứng (Jimeng Seedance) trên bảng điều khiển trước</p>
        </div>
      </div>
      <el-form label-width="0" style="margin-top: 8px">
        <el-form-item>
          <el-input
            v-model="oneKeyVolcKey"
            type="password"
            placeholder="Nhập API Key Volcengine (Ark)"
            show-password-on="click"
            clearable
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="oneKeyVolcVisible = false">Huỷ</el-button>
        <el-button type="success" :loading="oneKeyVolcSaving" :disabled="!oneKeyVolcKey.trim()" @click="submitOneKeyVolc">
          Đồng ý, tạo cấu hình một chạm
        </el-button>
      </template>
    </el-dialog>

    <!-- 一键配置 Agnes -->
    <el-dialog
      v-model="oneKeyAgnesVisible"
      title="Cấu hình nhanh Agnes AI"
      width="520px"
      :close-on-click-modal="false"
      @closed="oneKeyAgnesKey = ''"
    >
      <div class="one-key-help">
        <div class="one-key-section">
          <div class="one-key-section-title">📋 Sẽ tự tạo các cấu hình sau</div>
          <ul class="one-key-list">
            <li><b>Văn bản/hội thoại</b>: Agnes 3.0 Flash (agnes-3.0-flash) — viết kịch bản</li>
            <li><b>Văn bản tạo ảnh</b>: Agnes Image 2.5 Flash — ảnh nhân vật/bối cảnh/đạo cụ</li>
            <li><b>Tạo ảnh phân cảnh</b>: Agnes Image 2.5 Flash — hỗ trợ sửa theo ảnh tham chiếu</li>
            <li><b>Tạo video</b>: Agnes Video 2.5 Flash (agnes-video-2.5-flash) — tạo đoạn video</li>
          </ul>
        </div>
        <div class="one-key-section">
          <div class="one-key-section-title">🔑 Cách đăng ký API Key</div>
          <ol class="one-key-list">
            <li>Vào nền tảng Agnes:<a href="https://platform.agnes-ai.com/settings/apiKeys" target="_blank" class="one-key-link">platform.agnes-ai.com/settings/apiKeys</a></li>
            <li>Đăng ký/đăng nhập, vào Settings → API Keys</li>
            <li>Bấm «Create new secret key» để tạo khoá</li>
            <li>Sao chép Key rồi điền xuống dưới</li>
          </ol>
          <p class="one-key-note">💡 Một Key dùng được cho văn bản, ảnh, video; tài liệu API xem <a href="https://wiki.agnes-ai.com/zh-hans/docs/overview" target="_blank" class="one-key-link">wiki.agnes-ai.com</a></p>
        </div>
      </div>
      <el-form label-width="0" style="margin-top: 8px">
        <el-form-item>
          <el-input
            v-model="oneKeyAgnesKey"
            type="password"
            placeholder="Nhập API Key Agnes"
            show-password-on="click"
            clearable
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="oneKeyAgnesVisible = false">Huỷ</el-button>
        <el-button type="success" :loading="oneKeyAgnesSaving" :disabled="!oneKeyAgnesKey.trim()" @click="submitOneKeyAgnes">
          Đồng ý, tạo cấu hình một chạm
        </el-button>
      </template>
    </el-dialog>

    <!-- 即梦2角色认证：素材列表 -->
    <el-dialog
      v-model="jimeng2AssetsDialogVisible"
      title="Danh sách kho tư liệu (GET /api/business/v1/assets)"
      width="720px"
      class="jimeng2-assets-dialog"
      destroy-on-close
      @closed="onJimeng2AssetsDialogClosed"
    >
      <p class="field-tip" style="margin-top: 0">
        Tài liệu:
        <a href="https://83zi.com/sd2realperson.html" target="_blank" rel="noopener noreferrer">API quản lý tư liệu SilvaMux</a>
        ; chỉ <code>status=active</code> tư liệu mới dùng được để tham chiếu trong video Seedance 2.0.
      </p>
      <el-table v-loading="jimeng2AssetsLoading" :data="jimeng2AssetsRows" stripe max-height="420" empty-text="Chưa có dữ liệu hoặc chưa tải">
        <el-table-column prop="id" label="ID tư liệu" min-width="120" show-overflow-tooltip />
        <el-table-column prop="name" label="Tên" width="100" show-overflow-tooltip />
        <el-table-column prop="asset_type" label="Loại" width="88" />
        <el-table-column prop="status" label="Trạng thái" width="96">
          <template #default="{ row }">
            <el-tag :type="row.status === 'active' ? 'success' : row.status === 'failed' ? 'danger' : 'info'" size="small">
              {{ row.status || '—' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="asset_url" label="asset_url" min-width="160" show-overflow-tooltip />
        <el-table-column prop="url" label="URL gốc" min-width="120" show-overflow-tooltip />
        <el-table-column prop="created_at" label="Thời gian tạo" width="160" show-overflow-tooltip />
      </el-table>
      <div v-if="jimeng2AssetsHasMore" style="margin-top: 12px; text-align: center">
        <el-button :loading="jimeng2AssetsLoading" @click="loadMoreJimeng2MaterialAssets">Tải thêm</el-button>
      </div>
      <template #footer>
        <el-button @click="jimeng2AssetsDialogVisible = false">Đóng</el-button>
      </template>
    </el-dialog>

    <!-- 测试连接 -->
    <el-dialog v-model="testVisible" title="Kiểm tra kết nối" width="420px">
      <p v-if="testResult === null">Đang kiểm tra…</p>
      <template v-else-if="testResult">
        <el-alert
          v-if="testServiceType === 'image' || testServiceType === 'storyboard_image' || testServiceType === 'video'"
          type="success"
          title="Kết nối thành công"
          description="API Key hợp lệ, mạng đã thông. Lưu ý: kiểm tra chỉ xác nhận Key hợp lệ, không tạo ảnh/video thật; điền sai tên model, tài khoản chưa mở tính năng hoặc thiếu hạn mức thì khi tạo thật vẫn có thể lỗi."
          show-icon
          :closable="false"
        />
        <el-alert
          v-else
          type="success"
          title="Kết nối thành công"
          description="API tạo văn bản đã phản hồi bình thường."
          show-icon
          :closable="false"
        />
      </template>
      <el-alert v-else type="error" :title="testError || 'Kết nối thất bại'" show-icon :closable="false" />
      <template #footer>
        <el-button @click="testVisible = false">Đóng</el-button>
      </template>
    </el-dialog>

    <!-- 一键换Key（锁定模式） -->
    <el-dialog v-model="bulkKeyVisible" title="Đổi Key nhanh" width="440px" :close-on-click-modal="false">
      <el-alert
        type="warning"
        :closable="false"
        style="margin-bottom: 16px"
        title="Thao tác này sẽ thay API Key của mọi cấu hình, hãy chắc chắn Key mới dùng được rồi mới gửi."
        show-icon
      />
      <el-form label-width="80px">
        <el-form-item label="API Key mới">
          <el-input
            v-model="bulkKeyInput"
            type="password"
            show-password
            placeholder="Dán API Key mới"
            clearable
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="bulkKeyVisible = false">Huỷ</el-button>
        <el-button type="primary" :loading="bulkKeySaving" :disabled="!bulkKeyInput.trim()" @click="submitBulkKey">Xác nhận thay</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, MagicStick, QuestionFilled, Download, Upload, Delete, ChatDotRound, Picture, Film, VideoCamera, Key, Microphone, Folder } from '@element-plus/icons-vue'
import { aiAPI } from '@/api/ai'
import { generationSettingsAPI } from '@/api/prompts'
import PromptEditor from '@/components/PromptEditor.vue'
import SceneModelMap from '@/components/SceneModelMap.vue'
import Sd2AssetManagement from '@/components/Sd2AssetManagement.vue'

const activeTab = ref('configs')
const importFileRef = ref(null)

// ---- 生成设置 ----
const genConcurrencyInput = ref(3)
const genVideoConcurrencyInput = ref(3)
const genSettingSaving = ref(false)
const genSettingSaved = ref(false)

async function loadGenerationSettings() {
  try {
    const res = await generationSettingsAPI.get()
    genConcurrencyInput.value = res?.concurrency ?? 3
    genVideoConcurrencyInput.value = res?.video_concurrency ?? 3
  } catch (_) {}
}

function onConcurrencyChange(val) {
  const n = Number(val)
  if (!isNaN(n) && n >= 1) genConcurrencyInput.value = Math.min(20, Math.max(1, Math.round(n)))
}

function onVideoConcurrencyChange(val) {
  const n = Number(val)
  if (!isNaN(n) && n >= 1) genVideoConcurrencyInput.value = Math.min(20, Math.max(1, Math.round(n)))
}

async function saveGenerationSettings() {
  const n = Number(genConcurrencyInput.value)
  const nv = Number(genVideoConcurrencyInput.value)
  if (isNaN(n) || n < 1 || n > 20) {
    ElMessage.warning('Số ảnh song song phải là số nguyên từ 1 đến 20')
    return
  }
  if (isNaN(nv) || nv < 1 || nv > 20) {
    ElMessage.warning('Số video song song phải là số nguyên từ 1 đến 20')
    return
  }
  genSettingSaving.value = true
  genSettingSaved.value = false
  try {
    await generationSettingsAPI.update({ concurrency: Math.round(n), video_concurrency: Math.round(nv) })
    genSettingSaved.value = true
    setTimeout(() => { genSettingSaved.value = false }, 2000)
  } catch (e) {
    ElMessage.error('Lưu thất bại:' + (e?.message || ''))
  } finally {
    genSettingSaving.value = false
  }
}
const loading = ref(false)
const list = ref([])
const selectedRows = ref([])
const batchDeleting = ref(false)
const vendorLock = ref({ enabled: false, config_file: '' })
const dialogVisible = ref(false)
const editingId = ref(null)
const saving = ref(false)
const showProtocolHelp = ref(false)
const bulkKeyVisible = ref(false)
const bulkKeyInput = ref('')
const bulkKeySaving = ref(false)
const jimeng2AssetsDialogVisible = ref(false)
const jimeng2AssetsLoading = ref(false)
const jimeng2AssetsRows = ref([])
const jimeng2AssetsHasMore = ref(false)
const jimeng2AssetsNextCursor = ref(null)
const formRef = ref(null)
const form = ref({
  service_type: 'text',
  name: '',
  provider: '',
  api_protocol: '',
  base_url: '',
  api_key: '',
  endpoint: '',
  query_endpoint: '',
  modelText: '',
  default_model: '',
  deepseek_thinking: 'disabled',
  deepseek_reasoning_effort: 'high',
  priority: 0,
  is_default: false,
  // 确认该视频配置支持全能模式多图参考（存 settings.supports_universal_omni）
  supports_universal_omni: false,
  // 可灵 Omni 官方 AK/SK（存 settings，后端生成 JWT）
  kling_access_key: '',
  kling_secret_key: '',
  kling_secret_key_base64: false,
  // TTS 专属字段
  voice_id: '',
  group_id: '',
})
const presetModelPick = ref('')

const formModelList = computed(() => parseModelText(form.value.modelText))

// 保证「生成时默认使用」下拉有可选且选中值在列表内，否则会不显示或修改无效
watch(
  () => [formModelList.value, form.value.default_model],
  () => {
    const list = formModelList.value
    if (list.length === 0) return
    const current = form.value.default_model
    if (!current || !list.includes(current)) {
      form.value.default_model = list[0] || ''
    }
  },
  { immediate: true }
)

function onServiceTypeChange() {
  const st = form.value.service_type || 'text'
  if (st === 'jimeng2_character_auth') {
    if (!form.value.provider || form.value.provider === CUSTOM_PROVIDER_SENTINEL) {
      form.value.provider = 'jimeng_material_api'
    }
    const p = form.value.provider
    const pcfg = (providerConfigs.jimeng2_character_auth || []).find((x) => x.id === p)
    if (pcfg) {
      if (!form.value.base_url?.trim()) form.value.base_url = getBaseUrlForProvider(p)
      form.value.modelText = '-'
      form.value.default_model = '-'
      form.value.endpoint = ''
      form.value.query_endpoint = ''
      form.value.api_protocol = ''
    }
    if (!editingId.value && !form.value.name?.trim()) {
      form.value.name = 'Xác thực nhân vật Jimeng 2'
    }
    return
  }
  const listByType = providerConfigs[st] || []
  const current = form.value.provider
  if (!current || !listByType.some((p) => p.id === current)) {
    form.value.provider = ''
    form.value.base_url = ''
    form.value.modelText = ''
    form.value.default_model = ''
  }
}

function onPresetModelSelect(value) {
  if (!value) return
  const listParsed = parseModelText(form.value.modelText)
  if (listParsed.includes(value)) {
    presetModelPick.value = ''
    return
  }
  const append = listParsed.length ? '\n' + value : value
  form.value.modelText = (form.value.modelText || '').trim() + append
  presetModelPick.value = ''
}
const rules = computed(() => ({
  service_type: [{ required: true, message: 'Hãy chọn loại dịch vụ', trigger: 'change' }],
  name: [{ required: true, message: 'Hãy nhập tên', trigger: 'blur' }],
  provider: [{ required: true, message: 'Hãy chọn hoặc nhập nhà cung cấp', trigger: 'change' }],
  base_url: [{ required: true, message: 'Hãy nhập Base URL', trigger: 'blur' }],
  api_key: [
    {
      validator: (_rule, v, cb) => {
        const st = form.value.service_type
        if (st === 'jimeng2_character_auth') {
          if (v != null && String(v).trim()) return cb()
          return cb(new Error('Hãy điền Token'))
        }
        const proto = form.value.api_protocol
        const ak = (form.value.kling_access_key || '').trim()
        const sk = (form.value.kling_secret_key || '').trim()
        if (st === 'video' && proto === 'kling_omni' && ak && sk) return cb()
        if (v != null && String(v).trim()) return cb()
        cb(new Error('Hãy nhập API Key, hoặc dùng AccessKey + SecretKey chính thức (có thể bỏ trống API Key)'))
      },
      trigger: 'blur',
    },
  ],
}))
const testVisible = ref(false)
const testResult = ref(null)
const testServiceType = ref('')
const testError = ref('')
const oneKeyTongyiVisible = ref(false)
const oneKeyTongyiKey = ref('')
const oneKeyTongyiSaving = ref(false)
const oneKeyCheapSeedance2Visible = ref(false)
const oneKeyCheapSeedance2Key = ref('')
const oneKeyCheapSeedance2Saving = ref(false)
const oneKeyVolcVisible = ref(false)
const oneKeyVolcKey = ref('')
const oneKeyVolcSaving = ref(false)
const oneKeyAgnesVisible = ref(false)
const oneKeyAgnesKey = ref('')
const oneKeyAgnesSaving = ref(false)

/** 预设厂商与模型（与参考前端一致） */
const providerConfigs = {
  text: [
    { id: 'openai', name: 'OpenAI', models: ['gpt-4o', 'gpt-4', 'gpt-3.5-turbo'] },
    { id: 'volcengine', name: 'Volcengine', models: ['deepseek-v3-2-251201', 'doubao-1-5-pro-32k-250115', 'kimi-k2-thinking-251104'] },
    // { id: 'chatfire', name: 'Chatfire', models: ['gemini-3-flash-preview', 'claude-sonnet-4-5-20250929', 'doubao-seed-1-8-251228'] },
    { id: 'gemini', name: 'Google Gemini', models: ['gemini-2.5-pro', 'gemini-3-flash-preview'] },
    { id: 'deepseek', name: 'DeepSeek', models: ['deepseek-v4-flash', 'deepseek-v4-pro'] },
    { id: 'qwen', name: 'Tongyi Qianwen', models: ['qwen3-max', 'qwen-plus', 'qwen-flash'] },
    { id: 'agnes', name: 'Agnes AI', models: ['agnes-3.0-flash', 'agnes-2.5-flash', 'agnes-2.5-pro', 'agnes-2.0-flash'] }
  ],
  image: [
    { id: 'volcengine', name: 'Volcengine', models: ['doubao-seedream-4-5-251128', 'doubao-seedream-4-0-250828'] },
    { id: 'kling', name: 'Kling', models: ['kling-image', 'kling-omni-image'] },
    { id: 'nano_banana', name: 'NanoBanana', models: ['nano-banana-2', 'nano-banana-pro', 'nano-banana'] },
    // { id: 'chatfire', name: 'Chatfire', models: ['nano-banana-pro', 'doubao-seedream-4-5-251128', 'qwen-image'] },
    { id: 'gemini', name: 'Google Gemini', models: ['gemini-2.5-flash-image', 'gemini-2.5-flash-image-preview', 'gemini-3.1-flash-image-preview', 'gemini-3-pro-image-preview'] },
    { id: 'openai', name: 'OpenAI', models: ['dall-e-3', 'dall-e-2'] },
    { id: 'dashscope', name: 'Tongyi Wanxiang', models: ['wan2.6-image', 'qwen-image-edit-plus-2026-01-09', 'qwen-image-edit-plus', 'qwen-image-edit-max'] },
    { id: 'qwen_image', name: 'Tongyi Qianwen', models: ['qwen-image-max', 'qwen-image-plus', 'qwen-image'] },
    { id: 'agnes', name: 'Agnes AI', models: ['agnes-image-2.5-flash', 'agnes-image-2.1-flash', 'agnes-image-2.0-flash'] }
  ],
  storyboard_image: [
    { id: 'dashscope', name: 'Tongyi Wanxiang', models: ['wan2.6-image', 'qwen-image-edit-plus-2026-01-09', 'qwen-image-edit-plus', 'qwen-image-edit-max'] },
    { id: 'volcengine', name: 'Volcengine', models: ['doubao-seedream-4-5-251128', 'doubao-seedream-4-0-250828'] },
    { id: 'kling', name: 'Kling', models: ['kling-image', 'kling-omni-image'] },
    { id: 'nano_banana', name: 'NanoBanana', models: ['nano-banana-2', 'nano-banana-pro', 'nano-banana'] },
    // { id: 'chatfire', name: 'Chatfire', models: ['nano-banana-pro', 'doubao-seedream-4-5-251128', 'qwen-image'] },
    { id: 'gemini', name: 'Google Gemini', models: ['gemini-2.5-flash-image', 'gemini-2.5-flash-image-preview', 'gemini-3.1-flash-image-preview', 'gemini-3-pro-image-preview'] },
    { id: 'openai', name: 'OpenAI', models: ['dall-e-3', 'dall-e-2'] },
    { id: 'agnes', name: 'Agnes AI', models: ['agnes-image-2.5-flash', 'agnes-image-2.1-flash', 'agnes-image-2.0-flash'] }
  ],
  video: [
    {
      id: 'cheap_seedance2',
      name: 'Seedance2 giá rẻ',
      models: ['wb-seedance-2-fast', 'wb-seedance-2.5'],
    },
    { id: 'klingai', name: 'Kling Omni chính thức (api-beijing.klingai.com)', models: ['kling-video-o1', 'kling-v3-omni'] },
    { id: 'ffir', name: 'Feier API / Kling Omni-Video (ffir.cn)', models: ['kling-video-o1', 'kling-v3-omni'] },
    { id: 'kling', name: 'Kling', models: ['kling-omni-video', 'kling-video', 'kling-motion-control'] },
    { id: 'vidu', name: 'Vidu', models: ['viduq2', 'viduq2-pro', 'viduq2-turbo', 'viduq3-pro'] },
    { id: 'volces', name: 'Volcengine', models: ['doubao-seedance-2-0-260128', 'doubao-seedance-2-0-fast-260128', 'doubao-seedance-1-5-pro-251215', 'doubao-seedance-1-0-lite-i2v-250428', 'doubao-seedance-1-0-lite-t2v-250428', 'doubao-seedance-1-0-pro-250528', 'doubao-seedance-1-0-pro-fast-251015'] },
    // { id: 'chatfire', name: 'Chatfire', models: ['doubao-seedance-1-5-pro-251215', 'doubao-seedance-1-0-lite-i2v-250428', 'doubao-seedance-1-0-lite-t2v-250428', 'doubao-seedance-1-0-pro-250528', 'doubao-seedance-1-0-pro-fast-251015', 'sora-2', 'sora-2-pro'] },
    { id: 'minimax_h3', name: 'MiniMax H3', models: ['MiniMax-H3'] },
    { id: 'minimax', name: 'MiniMax Hailuo', models: ['MiniMax-Hailuo-2.3', 'MiniMax-Hailuo-2.3-Fast', 'MiniMax-Hailuo-02'] },
    { id: 'gemini', name: 'Google Gemini (Veo)', models: ['veo-3.1-generate-preview', 'veo-3.0-generate-preview', 'veo-3.0-fast-generate-preview'] },
    { id: 'dashscope', name: 'Tongyi Wanxiang', models: ['wan2.6-r2v-flash', 'wan2.6-t2v', 'wan2.2-kf2v-flash', 'wan2.6-i2v-flash', 'wanx2.1-vace-plus'] },
    {
      id: 'jimeng_ai_api',
      name: 'Jimeng AI API (API Jimeng miễn phí tự dựng)',
      models: [
        'jimeng-video-seedance-2.0',
        'seedance-2.0',
        'jimeng-video-seedance-2.0-fast',
        'jimeng-video-3.0',
        'jimeng-video-3.0-pro',
        'jimeng-video-3.5-pro',
      ],
    },
    { id: 'openai', name: 'OpenAI', models: ['sora-2', 'sora-2-pro'] },
    { id: 'xai', name: 'xAI Grok Imagine', models: ['grok-imagine-video'] },
    { id: 'agnes', name: 'Agnes AI', models: ['agnes-video-2.5-flash', 'agnes-video-2.5', 'agnes-video-v2.0'] },
  ],
  tts: [
    { id: 'minimax', name: 'MiniMax T2A', models: ['speech-02-hd', 'speech-02-turbo'] },
  ],
  jimeng2_character_auth: [
    { id: 'jimeng_material_api', name: 'API tư liệu nghiệp vụ Jimeng (/api/business/v1)', models: ['-'] },
  ],
}

/** 厂商 id → 默认接口规范（api_protocol） */
const providerProtocolMap = {
  // image / storyboard_image
  volcengine: 'volcengine',
  volces: 'volcengine',
  volc: 'volcengine',
  nano_banana: 'nano_banana',
  dashscope: 'dashscope',
  qwen_image: 'dashscope',
  gemini: 'gemini',
  google: 'gemini',
  kling: 'kling',
  ffir: 'kling_omni',
  klingai: 'kling_omni',
  // video
  vidu: 'vidu',
  xai: 'xai',
  grok: 'xai',
  minimax: 'openai',
  minimax_h3: 'minimax_h3',
  openai: 'openai',
  cheap_seedance2: 'sora',
  chatfire: 'openai',
  qwen: 'openai',
  deepseek: 'openai',
  agnes: 'openai',
  jimeng_ai_api: 'jimeng_ai_api',
  jimeng_material_api: '',
}

/** 厂商 id → 默认 Base URL（与参考前端 AIConfigDialog 757-775 一致） */
function getBaseUrlForProvider(provider) {
  if (!provider) return ''
  const p = String(provider).toLowerCase()
  if (p === 'gemini' || p === 'google') return 'https://generativelanguage.googleapis.com'
  if (p === 'minimax_h3') return 'https://api.minimaxi.com'
  if (p === 'minimax') return 'https://api.minimaxi.com/v1'
  if (p === 'volces' || p === 'volcengine') return 'https://ark.cn-beijing.volces.com/api/v3'
  if (p === 'openai') return 'https://api.openai.com/v1'
  if (p === 'cheap_seedance2') return 'https://workbench.ohmybb.xyz/api/openai'
  if (p === 'deepseek') return 'https://api.deepseek.com'
  if (p === 'dashscope') return 'https://dashscope.aliyuncs.com'
  if (p === 'qwen_image') return 'https://dashscope.aliyuncs.com'
  if (p === 'qwen') return 'https://dashscope.aliyuncs.com/compatible-mode/v1'
  if (p === 'nano_banana') return 'https://api.nanobananaapi.ai'
  if (p === 'vidu') return 'https://api.vidu.cn'
  if (p === 'kling') return 'https://api.klingai.com'
  if (p === 'klingai') return 'https://api-beijing.klingai.com'
  if (p === 'ffir') return 'https://ffir.cn'
  if (p === 'jimeng_ai_api') return 'http://127.0.0.1:8000'
  if (p === 'jimeng_material_api') return 'https://silvamux.tingyutech.com'
  if (p === 'xai' || p === 'grok') return 'https://api.x.ai'
  if (p === 'agnes') return 'https://apihub.agnes-ai.com/v1'
  return 'https://api.chatfire.site/v1'
}

const CUSTOM_PROVIDER_SENTINEL = '__custom__'

function parseSettings(settings) {
  if (!settings) return {}
  if (typeof settings === 'object') return settings
  try {
    const parsed = JSON.parse(settings)
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch (_) {
    return {}
  }
}

function isDeepSeekOfficial(provider, baseUrl) {
  const p = String(provider || '').trim().toLowerCase()
  const base = String(baseUrl || '').trim().toLowerCase()
  return p === 'deepseek' || base.includes('api.deepseek.com')
}

function resolveDeepSeekFormSettings(row) {
  const s = parseSettings(row?.settings)
  const nested = s.deepseek && typeof s.deepseek === 'object' ? s.deepseek : {}
  let thinking = s.deepseek_thinking || s.thinking || nested.thinking || nested.type || ''
  const model = String(row?.default_model || '').toLowerCase()
  if (!thinking && model === 'deepseek-chat') thinking = 'disabled'
  if (!thinking && model === 'deepseek-reasoner') thinking = 'enabled'
  if (thinking !== 'enabled' && thinking !== 'disabled') thinking = 'disabled'

  let effort = s.deepseek_reasoning_effort || s.reasoning_effort || nested.reasoning_effort || nested.effort || 'high'
  effort = String(effort).toLowerCase() === 'max' ? 'max' : 'high'
  return { thinking, effort }
}

const isDeepSeekOfficialForm = computed(() => (
  form.value.service_type === 'text'
  && isDeepSeekOfficial(form.value.provider, form.value.base_url)
))

/** 当前服务类型下的预设厂商列表（编辑时若当前 provider 不在列表则补一项；末尾始终附一项自定义入口） */
const availableProviderOptions = computed(() => {
  const st = form.value.service_type || 'text'
  const listByType = providerConfigs[st] || []
  const current = form.value.provider
  let result = [...listByType]
  if (editingId.value && current && current !== CUSTOM_PROVIDER_SENTINEL && !listByType.some((p) => p.id === current)) {
    result = [{ id: current, name: current + ' (hiện tại)', models: [] }, ...result]
  }
  result.push({ id: CUSTOM_PROVIDER_SENTINEL, name: '✏️ Tuỳ chỉnh (nhập thẳng tên nhà cung cấp)', models: [] })
  return result
})

/** 当前厂商的预设模型列表（用于追加预设模型） */
const availableModels = computed(() => {
  const st = form.value.service_type
  const provider = form.value.provider
  if (!st || !provider) return []
  const p = (providerConfigs[st] || []).find((x) => x.id === provider)
  return p?.models || []
})

/** 根据当前厂商/协议/base_url 推算实际将使用的接口地址，供用户核对 */
const endpointPreviewInfo = computed(() => {
  const { provider, api_protocol, base_url, service_type, endpoint, query_endpoint } = form.value
  const p = String(provider || '').toLowerCase()
  const proto = api_protocol || providerProtocolMap[p] || ''
  const base = (base_url || '').replace(/\/$/, '')

  if (service_type === 'jimeng2_character_auth') {
    const root = base || '(hãy điền URL cổng)'
    const hasReal = !root.startsWith('(')
    return {
      submit: `${root}/api/business/v1/assets`,
      query: hasReal ? `${root}/api/business/v1/assets/{assetId}` : null,
      isAuto: true,
      isJimeng2Auth: true,
    }
  }

  if (!base && !proto && !p) return null

  let submitPath = '', queryPath = ''

  if (service_type === 'text') {
    submitPath = '/chat/completions'
  } else if (service_type === 'tts') {
    if (p === 'minimax') {
      submitPath = '/t2a_v2?GroupId={group_id}'
    } else {
      submitPath = endpoint || '/tts'
    }
  } else if (service_type === 'image' || service_type === 'storyboard_image') {
    if (endpoint) {
      submitPath = endpoint
    } else if (proto === 'volcengine' || p === 'volcengine' || p === 'volces') {
      submitPath = '/images/generations'
    } else if (proto === 'dashscope' || p === 'dashscope' || p === 'qwen_image') {
      submitPath = '/api/v1/services/aigc/multimodal-generation/generation'
    } else if (proto === 'gemini' || p === 'gemini') {
      const m = form.value.default_model || '{Tên model}'
      submitPath = `/v1beta/models/${m}:generateContent?key=***`
      return { submit: base + submitPath, query: null, isAuto: true, isGemini: true }
    } else if (proto === 'nano_banana' || p === 'nano_banana') {
      submitPath = '/v1/images/generations'  // nano_banana base_url 无 /v1
    } else if (proto === 'kling' || p === 'kling' || p === 'klingai') {
      submitPath = '/v1/images/generations'
    } else {
      submitPath = '/images/generations'  // openai 兼容：base_url 已含 /v1
    }
    } else if (service_type === 'video') {
    if (endpoint) {
      submitPath = endpoint
    } else if (proto === 'volcengine_omni') {
      submitPath = '/contents/generations/tasks'
    } else if (proto === 'volcengine' || p === 'volces' || p === 'volcengine') {
      submitPath = '/videos/generations'
    } else if (proto === 'dashscope' || p === 'dashscope') {
      submitPath = '/api/v1/services/aigc/video-generation/video-synthesis'
    } else if (proto === 'gemini' || p === 'gemini') {
      const m = form.value.default_model || '{Tên model}'
      return {
        submit: `${base}/v1beta/models/${m}:predictLongRunning  (API Key đặt ở header: x-goog-api-key)`,
        query: `${base}/v1beta/{operationName}  (operationName do phản hồi gửi trả về)`,
        isAuto: true,
        isGemini: true
      }
    } else if (proto === 'vidu' || p === 'vidu') {
      submitPath = '/ent/v2/img2video'
    } else if (proto === 'sora') {
      submitPath = '/v1/videos'
    } else if (proto === 'agnes' || p === 'agnes') {
      submitPath = '/videos'
    } else if (proto === 'minimax_h3' || p === 'minimax_h3') {
      submitPath = '/v2/video_generation'
    } else if (proto === 'xai') {
      submitPath = '/v1/videos/generations'
    } else if (proto === 'veo3') {
      submitPath = '/v1/video/create'
    } else if (proto === 'jimeng_ai_api' || p === 'jimeng_ai_api') {
      submitPath = endpoint || '/v1/videos/generations'
      return {
        submit: (base || '(hãy điền Base URL)') + submitPath + '  (Bearer là Session Jimeng, nhiều tài khoản cách nhau bằng dấu phẩy; đồng bộ trả về data[0].url)',
        query: null,
        isAuto: true,
      }
    } else if (proto === 'kling_omni' || p === 'ffir' || p === 'klingai') {
      const omniFfir = p === 'ffir' || /ffir\.cn/i.test(base)
      const omniKlingOfficial = p === 'klingai' || /api(-beijing|-singapore)?\.klingai\.com/i.test(base)
      submitPath = omniFfir ? '/kling/v1/videos/omni-video' : omniKlingOfficial ? '/v1/videos/omni-video' : '/kling/v1/videos/omni-video'
    } else if (proto === 'kling' || p === 'kling' || p === 'klingai') {
      submitPath = '/v1/videos/text2video (T2V) hoặc /v1/videos/image2video (I2V)'
    } else if (p === 'minimax') {
      submitPath = '/video_generation'  // minimax base_url 已含 /v1
    } else {
      submitPath = '/v1/video/create'
    }

    if (query_endpoint) {
      queryPath = query_endpoint
    } else if (proto === 'volcengine_omni') {
      queryPath = '/contents/generations/tasks/{taskId}'
    } else if (proto === 'volcengine' || p === 'volces' || p === 'volcengine') {
      queryPath = '/tasks/{taskId}/info'
    } else if (proto === 'dashscope' || p === 'dashscope') {
      queryPath = '/api/v1/tasks/{taskId}/info'
    } else if (proto === 'vidu' || p === 'vidu') {
      queryPath = '/ent/v2/tasks/{taskId}/creations'
    } else if (proto === 'sora') {
      queryPath = '/v1/videos/{taskId}'
    } else if (proto === 'agnes' || p === 'agnes') {
      const m = String(form.value.default_model || form.value.modelText || '').toLowerCase()
      queryPath = /agnes-video-2\.5/.test(m)
        ? '/agnesapi?video_id={videoId}&model_name={model}'
        : '/videos/{taskId}'
    } else if (proto === 'minimax_h3' || p === 'minimax_h3') {
      queryPath = '/v2/query/video_generation/{taskId}'
    } else if (proto === 'xai') {
      queryPath = '/v1/videos/{taskId}'
    } else if (proto === 'veo3') {
      queryPath = '/v1/video/query?id={taskId}'
    } else if (proto === 'kling_omni' || p === 'ffir' || p === 'klingai') {
      const omniFfirQ = p === 'ffir' || /ffir\.cn/i.test(base)
      const omniKlingOfficialQ = p === 'klingai' || /api(-beijing|-singapore)?\.klingai\.com/i.test(base)
      queryPath = omniFfirQ
        ? '/kling/v1/images/omni-image/{taskId}'
        : omniKlingOfficialQ
          ? '/v1/videos/omni-video/{taskId}'
          : '/kling/v1/images/omni-image/{taskId}'
    } else if (proto === 'kling' || p === 'kling' || p === 'klingai') {
      queryPath = '/v1/videos/{videoType}/{taskId}(tự chọn theo loại tác vụ)'
    } else if (p === 'minimax') {
      queryPath = '/query/video_generation?task_id={taskId}'  // minimax base_url 已含 /v1
    } else if (proto !== 'gemini' && p !== 'gemini') {
      queryPath = '/v1/video/query?id={taskId}'
    }
  }

  const submitUrl = base ? (base + submitPath) : ('(chưa điền Base URL)' + submitPath)
  const queryUrl = queryPath ? (base ? base + queryPath : '(chưa điền Base URL)' + queryPath) : null

  if (!submitPath) return null
  return {
    submit: submitUrl,
    query: queryUrl,
    isAuto: !endpoint  // 端点是自动推断的（非用户手填）
  }
})

function onProviderChange(providerId) {
  if (providerId === CUSTOM_PROVIDER_SENTINEL) {
    form.value.provider = ''
    form.value.api_protocol = ''
    form.value.base_url = ''
    form.value.modelText = ''
    form.value.default_model = ''
    return
  }
  const st = form.value.service_type || 'text'
  const p = (providerConfigs[st] || []).find((x) => x.id === providerId)
  if (!p) {
    form.value.base_url = ''
    form.value.modelText = ''
    form.value.default_model = ''
    return
  }
  form.value.base_url = getBaseUrlForProvider(providerId)
  form.value.modelText = (p.models || []).join('\n')
  form.value.default_model = (p.models && p.models[0]) || ''
  if (providerId === 'deepseek') {
    form.value.deepseek_thinking = 'disabled'
    form.value.deepseek_reasoning_effort = 'high'
  }
  // 自动填充接口规范
  form.value.api_protocol = providerProtocolMap[providerId] || (st === 'text' ? '' : 'openai')
  if (st === 'video' && providerId === 'jimeng_ai_api') {
    form.value.endpoint = ''
    form.value.query_endpoint = ''
  }
  if (st === 'video' && providerId === 'cheap_seedance2') {
    form.value.api_protocol = 'sora'
    form.value.endpoint = '/v1/videos'
    form.value.query_endpoint = '/v1/videos/{taskId}'
    form.value.supports_universal_omni = true
  }
  if (st === 'video' && (providerId === 'ffir' || providerId === 'klingai')) {
    if (providerId === 'ffir') {
      form.value.endpoint = '/kling/v1/videos/omni-video'
      form.value.query_endpoint = '/kling/v1/images/omni-image/{taskId}'
    } else {
      form.value.endpoint = '/v1/videos/omni-video'
      form.value.query_endpoint = '/v1/videos/omni-video/{taskId}'
    }
  }
  if (st === 'video' && providerId === 'agnes') {
    form.value.api_protocol = 'agnes'
    form.value.endpoint = '/videos'
    form.value.query_endpoint = '/agnesapi'
  }
  if (st === 'video' && providerId === 'minimax_h3') {
    form.value.api_protocol = 'minimax_h3'
    form.value.endpoint = '/v2/video_generation'
    form.value.query_endpoint = '/v2/query/video_generation/{taskId}'
  }
  if (st === 'video' && providerId === 'minimax') {
    form.value.api_protocol = 'openai'
    form.value.endpoint = '/video_generation'
    form.value.query_endpoint = '/query/video_generation?task_id={taskId}'
  }
  if (!editingId.value) {
    form.value.name = (p.name || providerId) + ' ' + serviceTypeLabel(st)
  }
}

/** 通义一键配置用 */
const TONGYI_CONFIGS = [
  { service_type: 'text', name: 'Tongyi Qianwen', base_url: 'https://dashscope.aliyuncs.com/compatible-mode/v1', provider: 'qwen', model: ['qwen-plus'] },
  { service_type: 'image', name: 'Tongyi Wanxiang văn bản tạo ảnh', base_url: 'https://dashscope.aliyuncs.com', provider: 'dashscope', model: ['wan2.6-image'] },
  { service_type: 'image', name: 'Tongyi Qianwen văn bản tạo ảnh', base_url: 'https://dashscope.aliyuncs.com', provider: 'qwen_image', model: ['qwen-image-max', 'qwen-image-plus', 'qwen-image'] },
  { service_type: 'storyboard_image', name: 'Tongyi Wanxiang ảnh phân cảnh', base_url: 'https://dashscope.aliyuncs.com', provider: 'dashscope', model: ['wan2.6-image'] },
  { service_type: 'video', name: 'Tongyi Wanxiang', base_url: 'https://dashscope.aliyuncs.com', provider: 'dashscope', model: ['wan2.2-kf2v-flash'] }
]

/** 低价 Seedance2 一键配置（仅视频） */
const CHEAP_SEEDANCE2_CONFIGS = [
  {
    service_type: 'video',
    name: 'Video Seedance2 giá rẻ',
    provider: 'cheap_seedance2',
    api_protocol: 'sora',
    base_url: 'https://workbench.ohmybb.xyz/api/openai',
    endpoint: '/v1/videos',
    query_endpoint: '/v1/videos/{taskId}',
    model: ['wb-seedance-2-fast', 'wb-seedance-2.5'],
    settings: JSON.stringify({ supports_universal_omni: true }),
  },
]

/** 火山引擎一键配置用 */
const VOLCENGINE_CONFIGS = [
  { service_type: 'text', name: 'Văn bản Volcengine', base_url: 'https://ark.cn-beijing.volces.com/api/v3', provider: 'volcengine', model: ['deepseek-v3-2-251201', 'doubao-1-5-pro-32k-250115', 'kimi-k2-thinking-251104'] },
  { service_type: 'image', name: 'Volcengine Jimeng văn bản tạo ảnh', base_url: 'https://ark.cn-beijing.volces.com/api/v3', provider: 'volcengine', model: ['doubao-seedream-4-5-251128'] },
  { service_type: 'storyboard_image', name: 'Volcengine Jimeng ảnh phân cảnh', base_url: 'https://ark.cn-beijing.volces.com/api/v3', provider: 'volcengine', model: ['doubao-seedream-4-5-251128'] },
  { service_type: 'video', name: 'Volcengine Jimeng video', base_url: 'https://ark.cn-beijing.volces.com/api/v3', provider: 'volces', model: ['doubao-seedance-1-5-pro-251215'] }
]

/** Agnes 一键配置用（默认最新模型） */
const AGNES_CONFIGS = [
  { service_type: 'text', name: 'Văn bản Agnes', base_url: 'https://apihub.agnes-ai.com/v1', provider: 'agnes', api_protocol: 'openai', model: ['agnes-3.0-flash', 'agnes-2.5-flash'] },
  { service_type: 'image', name: 'Agnes văn bản tạo ảnh', base_url: 'https://apihub.agnes-ai.com/v1', provider: 'agnes', api_protocol: 'openai', model: ['agnes-image-2.5-flash', 'agnes-image-2.1-flash'] },
  { service_type: 'storyboard_image', name: 'Ảnh phân cảnh Agnes', base_url: 'https://apihub.agnes-ai.com/v1', provider: 'agnes', api_protocol: 'openai', model: ['agnes-image-2.5-flash', 'agnes-image-2.1-flash'] },
  { service_type: 'video', name: 'Video Agnes', base_url: 'https://apihub.agnes-ai.com/v1', provider: 'agnes', api_protocol: 'agnes', endpoint: '/videos', query_endpoint: '/agnesapi', model: ['agnes-video-2.5-flash', 'agnes-video-2.5', 'agnes-video-v2.0'] },
]

function serviceTypeLabel(t) {
  const map = {
    text: 'Văn bản',
    image: 'Văn bản tạo ảnh',
    storyboard_image: 'Tạo ảnh phân cảnh',
    video: 'Video',
    tts: 'Tổng hợp giọng nói TTS',
    jimeng2_character_auth: 'Xác thực nhân vật Jimeng 2',
    model_ark_asset: 'Kho tài sản SD2',
  }
  return map[t] || t
}

function onRowEdit(row) {
  if (row.service_type === 'model_ark_asset') {
    activeTab.value = 'sd2_assets'
    ElMessage.info('Hãy sửa cấu hình này ở thẻ «Quản lý tài sản SD2»')
    return
  }
  openEdit(row)
}

async function loadList() {
  loading.value = true
  try {
    list.value = await aiAPI.list()
  } catch (_) {
    list.value = []
  } finally {
    loading.value = false
  }
}

function parseModelText(text) {
  if (!text || !String(text).trim()) return []
  return String(text)
    .split(/[\n,，]/)
    .map((s) => s.trim())
    .filter(Boolean)
}

function resetForm() {
  editingId.value = null
  presetModelPick.value = ''
  form.value = {
    service_type: 'text',
    name: '',
    provider: '',
    api_protocol: '',
    base_url: '',
    api_key: '',
    endpoint: '',
    query_endpoint: '',
    modelText: '',
    default_model: '',
    deepseek_thinking: 'disabled',
    deepseek_reasoning_effort: 'high',
    priority: 0,
    is_default: true,  // 新增时默认勾选「设为默认」，便于理解当前会使用哪条配置
    supports_universal_omni: false,
    voice_id: '',
    group_id: '',
    kling_access_key: '',
    kling_secret_key: '',
    kling_secret_key_base64: false,
  }
  formRef.value?.resetFields?.()
}

function openAdd() {
  resetForm()
  dialogVisible.value = true
}

function openEdit(row) {
  editingId.value = row.id
  const model = Array.isArray(row.model) ? row.model : (row.model ? [row.model] : [])
  const modelList = model.map((m) => String(m).trim()).filter(Boolean)
  const defaultInList = row.default_model && modelList.includes(row.default_model)
  // TTS / 可灵 Omni 等从 settings 解析
  let voice_id = row.voice_id || ''
  let group_id = row.group_id || ''
  let kling_access_key = ''
  let kling_secret_key = ''
  let kling_secret_key_base64 = false
  let supports_universal_omni = false
  const deepseekSettings = resolveDeepSeekFormSettings(row)
  if (row.settings) {
    try {
      const s = JSON.parse(row.settings)
      if (row.service_type === 'tts') {
        voice_id = s.voice_id || voice_id
        group_id = s.group_id || group_id
      }
      if (row.service_type === 'video' && row.api_protocol === 'kling_omni') {
        kling_access_key = s.kling_access_key || ''
        kling_secret_key = s.kling_secret_key || ''
        kling_secret_key_base64 = !!s.kling_secret_key_base64
      }
      if (row.service_type === 'video') {
        supports_universal_omni = !!(s.supports_universal_omni === true || s.supports_universal_omni === 1 || s.supports_universal_omni === 'true')
        if (String(row.provider || '').toLowerCase() === 'cheap_seedance2' && s.supports_universal_omni == null) {
          supports_universal_omni = true
        }
      }
    } catch (_) {}
  } else if (row.service_type === 'video' && String(row.provider || '').toLowerCase() === 'cheap_seedance2') {
    supports_universal_omni = true
  }
  form.value = {
    service_type: row.service_type,
    name: row.name,
    provider: row.provider,
    api_protocol: row.api_protocol || '',
    base_url: row.base_url,
    api_key: row.api_key,
    endpoint: row.endpoint || '',
    query_endpoint: row.query_endpoint || '',
    modelText: modelList.join('\n'),
    default_model: defaultInList ? row.default_model : (modelList[0] || ''),
    deepseek_thinking: deepseekSettings.thinking,
    deepseek_reasoning_effort: deepseekSettings.effort,
    priority: row.priority ?? 0,
    is_default: !!row.is_default,
    supports_universal_omni,
    voice_id,
    group_id,
    kling_access_key,
    kling_secret_key,
    kling_secret_key_base64,
  }
  dialogVisible.value = true
}

async function submit() {
  await formRef.value?.validate?.().catch(() => {})
  saving.value = true
  try {
    let modelList = parseModelText(form.value.modelText)
    if (form.value.service_type === 'jimeng2_character_auth' && modelList.length === 0) {
      modelList = ['-']
    }
    const defaultModel = form.value.default_model && modelList.includes(form.value.default_model)
      ? form.value.default_model
      : modelList[0] || null
    // TTS / 可灵 Omni 官方 AKSK / DeepSeek V4 / 视频全能多图开关 → settings
    let settings = undefined
    if (form.value.service_type === 'tts') {
      const s = {}
      if (form.value.voice_id) s.voice_id = form.value.voice_id
      if (form.value.group_id) s.group_id = form.value.group_id
      settings = Object.keys(s).length ? JSON.stringify(s) : null
    } else if (form.value.service_type === 'video') {
      let baseS = {}
      if (editingId.value) {
        const prev = list.value.find((r) => r.id === editingId.value)
        if (prev?.settings) {
          try {
            baseS = JSON.parse(prev.settings)
          } catch (_) {}
        }
      }
      if (form.value.api_protocol === 'kling_omni') {
        if ((form.value.kling_access_key || '').trim()) baseS.kling_access_key = form.value.kling_access_key.trim()
        else delete baseS.kling_access_key
        if ((form.value.kling_secret_key || '').trim()) baseS.kling_secret_key = form.value.kling_secret_key.trim()
        else delete baseS.kling_secret_key
        if (form.value.kling_secret_key_base64) baseS.kling_secret_key_base64 = true
        else delete baseS.kling_secret_key_base64
      }
      if (form.value.supports_universal_omni) baseS.supports_universal_omni = true
      else delete baseS.supports_universal_omni
      settings = Object.keys(baseS).length ? JSON.stringify(baseS) : null
    } else if (isDeepSeekOfficialForm.value) {
      const prev = editingId.value ? list.value.find((r) => r.id === editingId.value) : null
      const baseS = parseSettings(prev?.settings)
      baseS.deepseek_thinking = form.value.deepseek_thinking === 'enabled' ? 'enabled' : 'disabled'
      if (baseS.deepseek_thinking === 'enabled') {
        baseS.deepseek_reasoning_effort = form.value.deepseek_reasoning_effort === 'max' ? 'max' : 'high'
      } else {
        delete baseS.deepseek_reasoning_effort
      }
      settings = Object.keys(baseS).length ? JSON.stringify(baseS) : null
    }
    const payload = {
      service_type: form.value.service_type,
      name: form.value.name,
      provider: form.value.provider,
      api_protocol: form.value.api_protocol || '',
      base_url: form.value.base_url,
      api_key: form.value.api_key,
      endpoint: form.value.endpoint || '',
      query_endpoint: form.value.query_endpoint || '',
      model: modelList,
      default_model: defaultModel,
      priority: form.value.priority,
      is_default: form.value.is_default,
      ...(settings !== undefined ? { settings } : {}),
    }
    if (editingId.value) {
      await aiAPI.update(editingId.value, payload)
      ElMessage.success('Lưu thành công')
    } else {
      await aiAPI.create(payload)
      ElMessage.success('Thêm thành công')
    }
    dialogVisible.value = false
    await loadList()
  } catch (e) {
    // request 已统一报错
  } finally {
    saving.value = false
  }
}

function openBulkKey() {
  bulkKeyInput.value = ''
  bulkKeyVisible.value = true
}

async function submitBulkKey() {
  const key = bulkKeyInput.value.trim()
  if (!key) return
  bulkKeySaving.value = true
  try {
    const res = await aiAPI.bulkUpdateKey(key)
    ElMessage.success(res?.message || 'Đã cập nhật API Key cho mọi cấu hình')
    bulkKeyVisible.value = false
    await loadList()
  } catch (_) {
  } finally {
    bulkKeySaving.value = false
  }
}

function onJimeng2AssetsDialogClosed() {
  jimeng2AssetsRows.value = []
  jimeng2AssetsNextCursor.value = null
  jimeng2AssetsHasMore.value = false
}

async function fetchJimeng2MaterialAssets(firstPage) {
  if (!form.value.base_url?.trim() || !form.value.api_key?.trim()) {
    ElMessage.warning('Hãy điền URL cổng và Token trước')
    return
  }
  if (firstPage) {
    jimeng2AssetsRows.value = []
    jimeng2AssetsNextCursor.value = null
    jimeng2AssetsHasMore.value = false
    jimeng2AssetsDialogVisible.value = true
  }
  jimeng2AssetsLoading.value = true
  try {
    const data = await aiAPI.listJimeng2MaterialAssets({
      base_url: form.value.base_url.trim(),
      api_key: form.value.api_key,
      limit: 20,
      cursor: firstPage ? undefined : jimeng2AssetsNextCursor.value || undefined,
    })
    const items = Array.isArray(data?.items) ? data.items : []
    if (firstPage) {
      jimeng2AssetsRows.value = items
    } else {
      jimeng2AssetsRows.value = [...jimeng2AssetsRows.value, ...items]
    }
    jimeng2AssetsNextCursor.value = data?.next_cursor ?? null
    jimeng2AssetsHasMore.value = !!data?.has_more
  } catch (_) {
    /* request 拦截器已 ElMessage */
  } finally {
    jimeng2AssetsLoading.value = false
  }
}

function openJimeng2MaterialAssetsDialog() {
  fetchJimeng2MaterialAssets(true)
}

function loadMoreJimeng2MaterialAssets() {
  if (!jimeng2AssetsHasMore.value || !jimeng2AssetsNextCursor.value) return
  fetchJimeng2MaterialAssets(false)
}

async function openTest(row) {
  if (row.service_type === 'jimeng2_character_auth') {
    ElMessage.info('Xác thực nhân vật Jimeng 2 không cần thử ở đây; sau khi lưu, hãy bấm «Xác thực SD2» trong «Tạo nhân vật» ở trang sáng tác để kiểm tra.')
    return
  }
  if (row.service_type === 'model_ark_asset') {
    ElMessage.info('Kho tài sản SD2 hãy dùng «Làm mới danh sách» ở thẻ «Quản lý tài sản SD2» để kiểm tra kết nối.')
    return
  }
  testVisible.value = true
  testResult.value = null
  testError.value = ''
  testServiceType.value = row.service_type || 'text'
  try {
    await aiAPI.testConnection({
      base_url: row.base_url,
      api_key: row.api_key,
      model: Array.isArray(row.model) ? row.model[0] : row.model,
      provider: row.provider,
      endpoint: row.endpoint,
      service_type: row.service_type,
      settings: row.settings
    })
    testResult.value = true
  } catch (e) {
    testResult.value = false
    testError.value = e?.message || 'Yêu cầu thất bại'
  }
}

async function onDelete(row) {
  await ElMessageBox.confirm(`Xoá cấu hình «${row.name}»?`, 'Xác nhận xoá', {
    type: 'warning'
  })
  try {
    await aiAPI.delete(row.id)
    ElMessage.success('Đã xoá')
    await loadList()
  } catch (_) {}
}

function onSelectionChange(rows) {
  selectedRows.value = rows
}

async function onBatchDelete() {
  if (!selectedRows.value.length) return
  await ElMessageBox.confirm(
    `Xoá ${selectedRows.value.length} cấu hình đã chọn? Không thể hoàn tác.`,
    'Xác nhận xoá hàng loạt',
    { type: 'warning', confirmButtonText: 'Xoá', confirmButtonClass: 'el-button--danger' }
  )
  batchDeleting.value = true
  let success = 0, failed = 0
  for (const row of selectedRows.value) {
    try {
      await aiAPI.delete(row.id)
      success++
    } catch (_) { failed++ }
  }
  batchDeleting.value = false
  selectedRows.value = []
  ElMessage.success(`Đã xoá ${success} mục${failed ? `, ${failed} mục thất bại` : ''}`)
  await loadList()
}

function openOneKeyTongyi() {
  oneKeyTongyiKey.value = ''
  oneKeyTongyiVisible.value = true
}

async function submitOneKeyTongyi() {
  const apiKey = oneKeyTongyiKey.value.trim()
  if (!apiKey) return
  oneKeyTongyiSaving.value = true
  try {
    for (const cfg of TONGYI_CONFIGS) {
      const models = cfg.model || []
      await aiAPI.create({
        service_type: cfg.service_type,
        name: cfg.name,
        provider: cfg.provider,
        base_url: cfg.base_url,
        api_key: apiKey,
        model: models,
        default_model: models[0] || null,
        priority: 10,
        is_default: true
      })
    }
    ElMessage.success('Đã tạo cấu hình Tongyi: văn bản, văn bản tạo ảnh, ảnh phân cảnh, video')
    oneKeyTongyiVisible.value = false
    await loadList()
  } catch (_) {
    // 错误已由 request 统一提示
  } finally {
    oneKeyTongyiSaving.value = false
  }
}

function openOneKeyCheapSeedance2() {
  oneKeyCheapSeedance2Key.value = ''
  oneKeyCheapSeedance2Visible.value = true
}

async function submitOneKeyCheapSeedance2() {
  const apiKey = oneKeyCheapSeedance2Key.value.trim()
  if (!apiKey) return
  oneKeyCheapSeedance2Saving.value = true
  try {
    for (const cfg of CHEAP_SEEDANCE2_CONFIGS) {
      const models = cfg.model || []
      await aiAPI.create({
        service_type: cfg.service_type,
        name: cfg.name,
        provider: cfg.provider,
        api_protocol: cfg.api_protocol || '',
        base_url: cfg.base_url,
        api_key: apiKey,
        model: models,
        default_model: models[0] || null,
        endpoint: cfg.endpoint || '',
        query_endpoint: cfg.query_endpoint || '',
        priority: 10,
        is_default: true,
        settings: cfg.settings || undefined,
      })
    }
    ElMessage.success('Đã tạo cấu hình video Seedance2 giá rẻ')
    oneKeyCheapSeedance2Visible.value = false
    await loadList()
  } catch (_) {
    // 错误已由 request 统一提示
  } finally {
    oneKeyCheapSeedance2Saving.value = false
  }
}

function openOneKeyVolc() {
  oneKeyVolcKey.value = ''
  oneKeyVolcVisible.value = true
}

async function submitOneKeyVolc() {
  const apiKey = oneKeyVolcKey.value.trim()
  if (!apiKey) return
  oneKeyVolcSaving.value = true
  try {
    for (const cfg of VOLCENGINE_CONFIGS) {
      const models = cfg.model || []
      await aiAPI.create({
        service_type: cfg.service_type,
        name: cfg.name,
        provider: cfg.provider,
        base_url: cfg.base_url,
        api_key: apiKey,
        model: models,
        default_model: models[0] || null,
        priority: 10,
        is_default: true
      })
    }
    ElMessage.success('Đã tạo cấu hình Volcengine: văn bản, văn bản tạo ảnh, ảnh phân cảnh, video')
    oneKeyVolcVisible.value = false
    await loadList()
  } catch (_) {
    // 错误已由 request 统一提示
  } finally {
    oneKeyVolcSaving.value = false
  }
}

function openOneKeyAgnes() {
  oneKeyAgnesKey.value = ''
  oneKeyAgnesVisible.value = true
}

async function submitOneKeyAgnes() {
  const apiKey = oneKeyAgnesKey.value.trim()
  if (!apiKey) return
  oneKeyAgnesSaving.value = true
  try {
    for (const cfg of AGNES_CONFIGS) {
      const models = cfg.model || []
      await aiAPI.create({
        service_type: cfg.service_type,
        name: cfg.name,
        provider: cfg.provider,
        api_protocol: cfg.api_protocol || '',
        base_url: cfg.base_url,
        api_key: apiKey,
        model: models,
        default_model: models[0] || null,
        endpoint: cfg.endpoint || '',
        query_endpoint: cfg.query_endpoint || '',
        priority: 10,
        is_default: true
      })
    }
    ElMessage.success('Đã tạo cấu hình Agnes: văn bản, văn bản tạo ảnh, ảnh phân cảnh, video')
    oneKeyAgnesVisible.value = false
    await loadList()
  } catch (_) {
    // 错误已由 request 统一提示
  } finally {
    oneKeyAgnesSaving.value = false
  }
}

async function exportConfigs() {
  try {
    const configs = await aiAPI.list()
    const exportData = configs.map(({ id, created_at, updated_at, ...rest }) => rest)
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `ai-configs-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
    ElMessage.success(`Đã xuất ${exportData.length} cấu hình`)
  } catch (e) {
    ElMessage.error('Xuất thất bại')
  }
}

function triggerImport() {
  importFileRef.value?.click()
}

async function importConfigs(event) {
  const file = event.target.files?.[0]
  if (!file) return
  try {
    const text = await file.text()
    const configs = JSON.parse(text)
    if (!Array.isArray(configs)) {
      ElMessage.error('Sai định dạng tệp, cần một mảng JSON')
      return
    }
    let success = 0
    let failed = 0
    for (const cfg of configs) {
      try {
        const models = Array.isArray(cfg.model) ? cfg.model : (cfg.model ? [cfg.model] : [])
        await aiAPI.create({
          service_type: cfg.service_type,
          name: cfg.name,
          provider: cfg.provider,
          api_protocol: cfg.api_protocol || null,
          base_url: cfg.base_url,
          api_key: cfg.api_key || '',
          endpoint: cfg.endpoint || null,
          query_endpoint: cfg.query_endpoint || null,
          model: models,
          default_model: cfg.default_model || null,
          priority: cfg.priority ?? 0,
          is_default: !!cfg.is_default,
          settings: cfg.settings || null
        })
        success++
      } catch (_) {
        failed++
      }
    }
    ElMessage.success(`Nhập xong: ${success} mục thành công${failed ? `, ${failed} mục thất bại` : ''}`)
    await loadList()
  } catch (e) {
    ElMessage.error('Nhập thất bại:' + (e.message || 'Lỗi đọc tệp'))
  } finally {
    event.target.value = ''
  }
}

async function loadVendorLock() {
  try {
    vendorLock.value = await aiAPI.getVendorLock()
  } catch (_) {
    vendorLock.value = { enabled: false, config_file: '' }
  }
}

onMounted(() => {
  loadVendorLock()
  loadList()
  loadGenerationSettings()
})
</script>

<style>
.provider-custom-option {
  border-top: 1px solid var(--el-border-color-light, #e4e7ed);
  margin-top: 4px;
  padding-top: 4px;
  color: var(--el-color-primary, #409eff) !important;
  font-style: italic;
}
</style>

<style scoped>
.ai-config-content {
  padding: 0;
}
.config-tabs {
  margin-top: -4px;
}
.tab-content {
  padding-top: 16px;
  max-height: calc(100vh - 320px);
  overflow-y: auto;
}
.content-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 16px;
}
.actions-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.actions-right {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

/* 过渡动画 */
.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.2s ease;
}
.fade-slide-enter-from,
.fade-slide-leave-to {
  opacity: 0;
  transform: translateX(8px);
}

/* 类型徽章 */
.type-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
  border: 1px solid transparent;
}
.type-icon {
  font-size: 13px;
  flex-shrink: 0;
}

/* 文本/对话 — 蓝色 */
.type-text {
  background: rgba(59, 130, 246, 0.12);
  color: #3b82f6;
  border-color: rgba(59, 130, 246, 0.25);
}
/* 文本生成图片 — 绿色 */
.type-image {
  background: rgba(16, 185, 129, 0.12);
  color: #10b981;
  border-color: rgba(16, 185, 129, 0.25);
}
/* 分镜图片生成 — 紫色 */
.type-storyboard_image {
  background: rgba(139, 92, 246, 0.12);
  color: #8b5cf6;
  border-color: rgba(139, 92, 246, 0.25);
}
/* 视频 — 橙色 */
.type-video {
  background: rgba(249, 115, 22, 0.12);
  color: #f97316;
  border-color: rgba(249, 115, 22, 0.25);
}
.jimeng2-assets-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 12px;
  width: 100%;
}
.jimeng2-assets-tip {
  flex: 1;
  min-width: 200px;
  margin: 0;
  line-height: 1.5;
}

.type-jimeng2_character_auth {
  background: rgba(20, 184, 166, 0.14);
  color: #0d9488;
  border-color: rgba(20, 184, 166, 0.28);
}

.type-model_ark_asset {
  background: rgba(99, 102, 241, 0.12);
  color: #6366f1;
  border-color: rgba(99, 102, 241, 0.25);
}

.no-default {
  color: #9ca3af;
  font-size: 13px;
}
.one-key-tip {
  margin: 0 0 12px;
  color: #606266;
  font-size: 13px;
  line-height: 1.5;
}
.one-key-not-recommended {
  margin-left: 4px;
  padding: 0 5px;
  font-size: 11px;
  line-height: 18px;
  border-radius: 4px;
  color: var(--el-color-warning, #e6a23c);
  background: var(--el-color-warning-light-9, #fdf6ec);
  border: 1px solid var(--el-color-warning-light-7, #f5dab1);
  vertical-align: middle;
}
.one-key-help {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.one-key-section {
  background: var(--el-fill-color-light, #f5f7fa);
  border-radius: 8px;
  padding: 12px 14px;
}
.one-key-section-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-primary, #303133);
  margin-bottom: 8px;
}
.one-key-list {
  margin: 0;
  padding-left: 20px;
  font-size: 13px;
  color: var(--el-text-color-regular, #606266);
  line-height: 1.8;
}
.one-key-list li {
  margin-bottom: 2px;
}
.one-key-link {
  color: var(--el-color-primary, #409eff);
  text-decoration: none;
}
.one-key-link:hover {
  text-decoration: underline;
}
.one-key-note {
  margin: 6px 0 0;
  font-size: 12px;
  color: var(--el-text-color-secondary, #909399);
  line-height: 1.5;
}
.one-key-note + .one-key-note {
  margin-top: 4px;
}
code {
  background: var(--el-fill-color, #f0f2f5);
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 12px;
  font-family: monospace;
}
.cfg-tip-content code {
  background: none;
  padding: 0;
  border-radius: 0;
  font-size: inherit;
  font-family: monospace;
}
.default-tip {
  margin: 0 0 16px;
  padding: 10px 12px;
  background: #f0f9ff;
  border-radius: 6px;
  font-size: 13px;
  color: #0369a1;
  line-height: 1.5;
}
.vendor-lock-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.vendor-lock-bar .vendor-lock-tip {
  flex: 1;
  margin-bottom: 0;
}
.vendor-bulk-key-btn {
  white-space: nowrap;
  flex-shrink: 0;
  color: #fff !important;
}
.vendor-lock-tip {
  margin-bottom: 16px;
}
.model-row { margin-bottom: 4px; }
.deepseek-settings {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}
.field-tip {
  margin: 6px 0 0;
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}
.form-label-tip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  white-space: nowrap;
}
.ph-section-title {
  font-size: 13px;
  font-weight: 600;
  color: #606266;
  padding: 4px 0 6px;
  border-bottom: 1px solid #ebeef5;
  margin-bottom: 4px;
}
.ph-tag {
  display: inline-block;
  font-size: 11px;
  padding: 1px 6px;
  border-radius: 3px;
  margin-right: 6px;
  font-weight: 600;
  vertical-align: middle;
}
.ph-tag-img {
  background: #ecf5ff;
  color: #409eff;
  border: 1px solid #b3d8ff;
}
.ph-tag-vid {
  background: #f0f9eb;
  color: #67c23a;
  border: 1px solid #b3e19d;
}
.cheap-seedance2-tip {
  margin: 0 0 16px;
}
.cheap-seedance2-link {
  color: #409eff;
  text-decoration: underline;
  font-weight: 600;
}
.cheap-seedance2-link:hover {
  color: #337ecc;
}
.protocol-help .ph-body {
  font-size: 13px;
  line-height: 1.7;
  color: #303133;
}
.protocol-help .ph-body pre {
  background: #f5f7fa;
  border-radius: 4px;
  padding: 8px 12px;
  font-size: 12px;
  line-height: 1.6;
  overflow-x: auto;
  margin: 6px 0 2px;
  white-space: pre-wrap;
  word-break: break-all;
}
.protocol-help .ph-body code {
  background: #f0f2f5;
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 12px;
}
.tip-icon {
  font-size: 13px;
  color: #909399;
  cursor: pointer;
  flex-shrink: 0;
  transition: color 0.15s;
}
.tip-icon:hover {
  color: #409eff;
}
.endpoint-preview-box {
  background: #f0f7ff;
  border: 1px solid #c6e0ff;
  border-radius: 6px;
  padding: 10px 14px;
  margin: -4px 0 14px;
  font-size: 12px;
}
.ep-preview-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  color: #409eff;
  margin-bottom: 8px;
  font-size: 12px;
}
.ep-auto-badge {
  background: #e6f1ff;
  color: #409eff;
  border: 1px solid #b3d8ff;
  border-radius: 3px;
  padding: 0 5px;
  font-size: 11px;
  font-weight: 400;
}
.ep-row {
  display: flex;
  align-items: flex-start;
  margin-bottom: 5px;
  gap: 6px;
  line-height: 1.5;
}
.ep-row:last-of-type {
  margin-bottom: 0;
}
.ep-label {
  flex-shrink: 0;
  color: #606266;
  min-width: 68px;
}
.ep-url {
  word-break: break-all;
  color: #303133;
  background: rgba(255,255,255,0.7);
  border: 1px solid #dce8fa;
  border-radius: 3px;
  padding: 1px 6px;
  font-family: 'Menlo', 'Consolas', monospace;
  font-size: 11.5px;
  line-height: 1.6;
}
.ep-tip {
  margin: 8px 0 0;
  font-size: 11px;
  color: #909399;
  line-height: 1.4;
}
.ep-tip-warn {
  color: #e6a23c;
}
.ep-box-gemini {
  background: #fffbf0;
  border-color: #f5dfa0;
}
.ep-box-gemini .ep-preview-header {
  color: #b8860b;
}
.ep-badge-gemini {
  background: #fef6e0;
  color: #b8860b;
  border-color: #f0d080;
}
.generation-settings {
  max-width: 600px;
}
.gs-section-title {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}
.gs-desc {
  font-size: 13px;
  color: #606266;
  line-height: 1.6;
  margin-bottom: 20px;
}
.gs-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.gs-label {
  font-size: 13px;
  color: #303133;
  font-weight: 500;
  white-space: nowrap;
}
.gs-unit {
  font-size: 13px;
  color: #606266;
  white-space: nowrap;
}
.gs-tip-box {
  margin-top: 20px;
  background: #f5f7fa;
  border-radius: 8px;
  padding: 14px 16px;
  font-size: 13px;
}
.gs-tip-title {
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}
.gs-tip-list {
  margin: 0 0 8px 16px;
  padding: 0;
  color: #606266;
  line-height: 1.8;
}
.gs-tip-note {
  color: #909399;
  font-size: 12px;
}
</style>
