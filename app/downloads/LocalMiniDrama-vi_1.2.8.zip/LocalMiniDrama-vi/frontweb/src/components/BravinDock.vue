<template>
  <div v-if="bravin.embedded" class="bravin-dock" :class="{ off: !bravin.connected }">
    <span class="bd-dot" :title="bravin.connected ? 'Đã nối với Bravin' : 'Chưa nối với Bravin'"></span>
    <span class="bd-label">
      <template v-if="bravin.bravinProject">Bravin: <b>{{ bravin.bravinProject }}</b></template>
      <template v-else>Bravin</template>
      <template v-if="bravin.autoPush"> · tự đẩy</template>
    </span>
    <button class="bd-btn" type="button" :disabled="!bravin.drama" @click="onSync"
      title="Đẩy ngay ảnh/video/âm thanh đã tạo của phim này vào thư viện Bravin">⇪ Đẩy</button>
    <button class="bd-btn bd-primary" type="button" :disabled="!bravin.drama" @click="onNew"
      :title="bravin.drama ? `Tạo dự án Bravin mới tên «${bravin.drama.title}»` : 'Mở một phim trước'">＋ Dự án</button>
  </div>
</template>

<script setup>
import { watch } from 'vue'
import { ElMessage } from 'element-plus'
import { bravin, requestNewProject, requestSyncNow } from '@/utils/bravinBridge'

function onNew() {
  if (!requestNewProject()) ElMessage.warning('Hãy mở một phim trước')
}
function onSync() { requestSyncNow() }

watch(() => bravin.lastPush, (v) => {
  if (v && v.count > 0) ElMessage.success(`Đã đẩy ${v.count} tệp vào thư viện Bravin`)
})
</script>

<style scoped>
.bravin-dock {
  position: fixed; right: 14px; bottom: 14px; z-index: 3000;
  display: flex; align-items: center; gap: 8px;
  padding: 6px 8px 6px 12px; border-radius: 999px;
  background: rgba(20, 22, 30, 0.92); color: #e8e9f0; font-size: 12px;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(6px);
}
.bd-dot { width: 8px; height: 8px; border-radius: 50%; background: #3ddc84; box-shadow: 0 0 6px #3ddc84; }
.off .bd-dot { background: #f5a524; box-shadow: none; }
.bd-label { white-space: nowrap; max-width: 260px; overflow: hidden; text-overflow: ellipsis; opacity: 0.9; }
.bd-btn {
  border: 1px solid rgba(255, 255, 255, 0.18); background: transparent; color: inherit;
  border-radius: 999px; padding: 5px 12px; font-size: 12px; cursor: pointer;
}
.bd-btn:hover:not(:disabled) { background: rgba(255, 255, 255, 0.08); }
.bd-btn:disabled { opacity: 0.4; cursor: not-allowed; }
.bd-primary { background: #6c5ce7; border-color: #6c5ce7; color: #fff; font-weight: 600; }
.bd-primary:hover:not(:disabled) { background: #7d6ef0; }
</style>
