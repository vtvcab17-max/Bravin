# web2 - 单页 AI 视频生成

与现有 `web` 并列的前端项目，实现**单页**从故事到成片的完整流程，对接现有 Node 后端 `backend-node`。

**包版本：** `1.2.8`（与仓库根目录 [CHANGELOG](../CHANGELOG.md) 一致）

## 功能流程

1. **故事生成**：输入梗概 + 风格/类型 → 创建项目并保存第一集剧本
2. **剧本生成**：编辑剧本、标题/语言/分镜风格 → 保存
3. **角色生成**：AI 生成角色列表 → 每个角色可「AI 生成」形象（使用下方配置的图片模型）
4. **道具生成**：从剧本提取 / 手动添加 → 每个道具可「AI 生成」图片
5. **场景生成**：从剧本提取场景 → 每个场景可「AI 生成」图片
6. **分镜生成**：根据当前集生成分镜
7. **视频配置**：分辨率、配乐、音效、画质、字幕、水印；**AI 模型配置**（图片生成模型、视频生成模型）
8. **生成视频**：提交合成任务

## 运行

```bash
# 安装依赖
npm install

# 开发（默认端口 3013，代理到后端 5679）
npm run dev

# 构建
npm run build
```

请先启动 `backend-node`（如 `http://localhost:5679`），并确保 `vite.config.js` 中 proxy 的 target 与后端一致。

## 技术栈

- Vue 3 + Vite
- Element Plus
- Pinia
- Vue Router
- Axios
- 纯 JavaScript（无 TypeScript）
