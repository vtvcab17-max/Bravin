#!/usr/bin/env bash
# Phim AI - LocalMiniDrama (tiếng Việt): chạy máy chủ + giao diện ở http://localhost:5679
set -e
cd "$(dirname "$0")/backend-node"
command -v node >/dev/null || { echo "Chưa có Node.js (cần 18+): https://nodejs.org"; exit 1; }
[ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ] || { echo "Cần Node.js 18 trở lên"; exit 1; }
[ -d node_modules/better-sqlite3 ] || { echo "Lần đầu: đang cài thư viện…"; npm install --omit=dev --no-audit --no-fund; }
( sleep 4; (xdg-open http://localhost:5679 || open http://localhost:5679) >/dev/null 2>&1 ) &
exec node src/server.js
