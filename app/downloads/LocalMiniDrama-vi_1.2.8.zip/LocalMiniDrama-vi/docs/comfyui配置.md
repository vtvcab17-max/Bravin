# Dùng ComfyUI làm máy tạo ảnh (qua giao diện OpenAI)

Chạy bằng PowerShell có sẵn của Windows.

```powershell
# 1. Bọc ComfyUI thành giao diện OpenAI API chuẩn
cd C:\ComfyUI
git clone https://github.com/pnyxai/comfyui-openai-api.git

# 2. Vào thư mục
cd C:\ComfyUI\comfyui-openai-api\apps\rust\comfyui-openai-api

# 3. Cài Rust (môi trường để dựng proxy): https://rust-lang.org/tools/install/

# 4. Dựng chương trình proxy
cargo clean
cargo build --release

# 5. Chạy. Thấy dòng "Proxy server listening on 0.0.0.0:8080" là thành công.
./target/release/comfyui-openai-api
```

Địa chỉ OpenAI API tạo được: `http://127.0.0.1:8080/v1/images/generations`
→ trong Cấu hình AI, thêm cấu hình loại **ảnh**, Base URL `http://127.0.0.1:8080/v1`.

Cảm ơn bạn 欧先生@全力以赴 trong nhóm người dùng đã soạn hướng dẫn gốc.
