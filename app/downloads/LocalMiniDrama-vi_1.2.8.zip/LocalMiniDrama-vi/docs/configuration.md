# Hướng dẫn cấu hình AI

**Điều hướng: [Trang chính](../README.md) | [Bắt đầu nhanh](quickstart.md) | [English](en.md) | [Bản gốc tiếng Trung](configuration.zh.md)**

---

## Vào trang cấu hình

Bấm **Cấu hình AI** ở góc trên phải. Mỗi loại dịch vụ (văn bản, ảnh, video, TTS…) cấu hình riêng, không ảnh hưởng nhau.

| Loại | Dùng để | Gợi ý |
|------|------|----------|
| Văn bản | viết kịch bản, trích nhân vật, kịch bản phân cảnh, tối ưu prompt | Qwen, Doubao Pro, DeepSeek, Gemini qua giao diện tương thích OpenAI |
| Ảnh | ảnh nhân vật, ảnh bối cảnh, ảnh phân cảnh | Tongyi Wanxiang, Doubao Seedream, Gemini, Kling |
| Video | đoạn video phân cảnh | Doubao Seedance (cổ điển, hoặc **Seedance 2.0 nhiều ảnh / chế độ toàn năng**), Kling |

> Ngôn ngữ AI **vi**: văn bản cho người đọc (truyện, kịch bản, thoại, thuyết minh) viết bằng tiếng Việt; prompt ảnh/video giữ tiếng Anh. Nên chọn mô hình văn bản viết tiếng Việt tốt (Qwen-Max, DeepSeek, Gemini, GPT…).

---

## Alibaba DashScope (Tongyi)

**Lấy API Key**: vào [Bailian](https://bailian.console.aliyun.com/) → đăng ký/đăng nhập → «Model Square» bật các mô hình cần dùng → «API-KEY» tạo khoá mới (bắt đầu bằng `sk-`). Tài khoản mới thường có hạn mức miễn phí.

| Loại | Mô hình | Ghi chú |
|------|--------|------|
| Văn bản | `qwen-turbo` | nhanh, rẻ, hợp tạo hàng loạt |
| Văn bản | `qwen-plus` | cân bằng, dùng hằng ngày |
| Văn bản | `qwen-max` | mạnh nhất, hợp viết kịch bản |
| Văn bản | `qwen-long` | ngữ cảnh rất dài |
| Ảnh | `wanx2.1-t2i-turbo` / `wanx2.1-t2i-plus` / `wanx-v1` | nhanh / chất lượng cao / bản cũ |
| Video | `wan2.1-t2v-turbo` / `wan2.1-t2v-plus` | nhanh / chất lượng cao |

```
Nhà cung cấp: DashScope
Base URL: https://dashscope.aliyuncs.com/compatible-mode/v1
API Key: sk-xxxxxxxxxxxxxxxx
Mô hình: qwen-plus (văn bản) / wanx2.1-t2i-turbo (ảnh) / wan2.1-t2v-turbo (video)
```

---

## Volcengine (Doubao)

**Lấy API Key**: vào [Volcengine Ark](https://console.volcengine.com/ark) → «Model Square» bật mô hình (văn bản/ảnh/video) → «API Key» tạo khoá.

> 💡 Video (Seedance) cần bật riêng và tính phí theo thời lượng, nhớ kiểm soát mức dùng.

| Loại | Mô hình | Endpoint ID | Ghi chú |
|------|--------|------------|------|
| Văn bản | `Doubao-pro-32k` | `doubao-pro-32k-241215` | đa dụng |
| Văn bản | `Doubao-lite-32k` | `doubao-lite-32k-241215` | rẻ |
| Văn bản | `Doubao-pro-128k` | `doubao-pro-128k-241215` | ngữ cảnh dài |
| Ảnh | `Doubao-seedream-4.5` | `doubao-seedream-4-5-251128` | ảnh chất lượng cao |
| Video | `Doubao-Seedance-1.0-pro-fast` | `doubao-seedance-1-0-pro-250528` | nhanh |
| Video | `Doubao-Seedance-1.5-pro` | `doubao-seedance-1-5-pro-251215` | chất lượng cao |
| Video | `Doubao-Seedance-2.0-pro` | `doubao-seedance-2-0-260128` | **Seedance 2.0**, nhiều ảnh tham chiếu; dùng với chuẩn giao diện **`volcengine_omni`** và **chế độ toàn năng** |
| Video | `Doubao-Seedance-2.0-fast` | `doubao-seedance-2-0-fast-260128` | Seedance 2.0 bản nhanh |

> Điền tên hiển thị hay Endpoint ID đều được, hệ thống tự đổi.

**Chế độ toàn năng và chuẩn giao diện**

- Mỗi phân cảnh có thể chuyển sang **chế độ toàn năng**: vùng giữa là **mô tả đoạn**, dùng **`@图片1`, `@图片2`…** để chỉ ảnh tham chiếu theo thứ tự (thường là bối cảnh → nhân vật → đồ vật; không gồm ảnh chính phân cảnh cổ điển; nên để **một dấu cách** sau `@图片N`). `@图片N` là cú pháp của nhà cung cấp, **giữ nguyên, không dịch**. Khi ô này có nội dung, lúc tạo video chỉ gửi đoạn văn này.
- Trong **Cấu hình AI → Video**, chọn **chuẩn giao diện** `volcengine_omni` (Seedance 2.0 nhiều ảnh) hoặc `kling_omni` (Kling Omni). Seedance 2.x mỗi đoạn được căn về **4–15 giây**; tối đa **9** ảnh tham chiếu.
- Trước khi tạo video, hệ thống kiểm tra cấu hình có khớp không; không khớp thì báo và cho phép ép chạy (hạ cấp dùng ảnh bối cảnh / ảnh chính phân cảnh). Chế độ cổ điển mà thiếu ảnh phân cảnh sẽ yêu cầu tạo ảnh trước.

```
Nhà cung cấp: Volcengine
Base URL: https://ark.cn-beijing.volces.com/api/v3
API Key: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
Mô hình: Doubao-pro-32k (văn bản) / Doubao-seedream-4.5 (ảnh) / Doubao-Seedance-1.0-pro-fast (video)
```

| Tham số video | Ý nghĩa | Mặc định |
|------|------|--------|
| Độ phân giải | `720p` / `1080p` / `480p` | `720p` |
| Thời lượng | số giây mỗi đoạn (4 / 5 / 8 / 10) | `5` |
| seed | hạt ngẫu nhiên, cố định để lặp lại kết quả | ngẫu nhiên |
| camera_fixed | cố định máy quay | `false` |
| watermark | thêm watermark | `false` |

---

## Mô hình chạy trên máy (Ollama…)

```
Nhà cung cấp: Tuỳ chỉnh / tương thích OpenAI
Base URL: http://localhost:11434/v1   (ví dụ Ollama)
API Key: ollama   (chuỗi bất kỳ)
Mô hình: qwen2.5:7b
```

> Mô hình trên máy thường chỉ dùng cho **văn bản**; ảnh/video cần API đám mây.

## Giao diện tương thích OpenAI khác

Mọi dịch vụ theo chuẩn OpenAI Chat Completions đều dùng được: DeepSeek, SiliconFlow, Groq, OpenRouter…

```
Base URL: https://your-api-endpoint/v1
API Key: your-api-key
Mô hình: your-model-name
```

---

## Cấu hình nhanh

Ở đầu trang Cấu hình AI có các nút **Cấu hình nhanh Tongyi / Volcengine / Agnes / Seedance2 giá rẻ**: tạo sẵn bộ cấu hình văn bản/ảnh/video, bạn chỉ cần dán API Key rồi lưu. Thư mục `各大平台中转站配置/` có sẵn tệp cấu hình mẫu của một số trạm trung chuyển, xem `HUONG_DAN.txt` trong đó.

## Kho ảnh trung gian

Một số API (Gemini tạo ảnh, xác thực nhân vật Seedance 2.0) cần ảnh có URL công khai. Cấu hình trong `backend-node/configs/config.yaml`:

```yaml
image_proxy:
  expire_hours: 2              # thời gian giữ bộ nhớ đệm (giờ)
  use_for_video: true
  upload_timeout_seconds: 180  # thời gian chờ tải lên (giây)
  upload_max_attempts: 2       # số lần thử lại
  # upload_url: https://your-proxy.example.com/api/upload
```

Không đặt `upload_url` thì dùng địa chỉ trung chuyển có sẵn. URL đệm hết hạn sẽ tự tải lại.

## Kiểm tra kết nối

Mỗi dòng cấu hình có nút **Kiểm tra**: gửi một yêu cầu ngắn, báo xanh nếu được, báo lỗi cụ thể nếu không (sai khoá, sai mô hình…).

---

## Câu hỏi thường gặp

**Sai hoặc hết hạn API Key?** Sửa dòng cấu hình tương ứng, lưu là có hiệu lực ngay.

**Báo «image size must be at least 3686400 pixels»**: yêu cầu điểm ảnh tối thiểu của Volcengine. Hệ thống tự tính độ phân giải theo tỉ lệ khung (tối thiểu 2560×1440); vẫn lỗi thì kiểm tra tham số size tự đặt.

**Video báo «model does not exist»**: kiểm tra đã bật mô hình trong Volcengine Ark và tên mô hình đúng.

**Tạo chậm?** Ảnh thường 15–60 giây, video 1–5 phút. Dùng mô hình có hậu tố `turbo` / `fast` để nhanh hơn. Gặp giới hạn 429 thì hệ thống tự thử lại.

---

[← Về trang chính](../README.md)
