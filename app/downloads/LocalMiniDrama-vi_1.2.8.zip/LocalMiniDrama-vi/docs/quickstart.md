# Bắt đầu nhanh / Hướng dẫn phát triển

**Điều hướng: [Trang chính](../README.md) | [English](en.md) | [Cấu hình AI](configuration.md) | [Bản gốc tiếng Trung](quickstart.zh.md)**

---

## Cách 1: chạy bản tiếng Việt (khuyên dùng)

| Cần có | Phiên bản |
|------|----------|
| Node.js | 18 trở lên (bản LTS ở https://nodejs.org) |
| Mạng | lần đầu, để `npm install` tải thư viện |

**Windows**: bấm đúp `CHAY_PHIM_AI.bat` ở thư mục gốc.
Lần đầu sẽ chạy `npm install` trong `backend-node` (vài phút), sau đó máy chủ chạy ở cổng **5679** và trình duyệt mở `http://localhost:5679`. Đóng cửa sổ dòng lệnh là tắt máy chủ.

**macOS / Linux**: `bash chay_phim_ai.sh`

Giao diện đã được dựng sẵn trong `frontweb/dist`, máy chủ phục vụ luôn giao diện nên chỉ cần một cổng.

Vào **Cấu hình AI** (góc trên phải), thêm API Key, rồi bắt đầu.

> 💡 Chưa biết lấy API Key ở đâu? Xem [Hướng dẫn cấu hình AI](configuration.md).

---

## Cách 2: chế độ phát triển

### 1. Máy chủ

```bash
cd backend-node
npm install
# sửa configs/config.yaml nếu cần (cổng, đường dẫn dữ liệu, ngôn ngữ)
npm start          # cổng mặc định 5679
npm run dev        # chế độ tự tải lại khi sửa mã
```

Máy chủ chạy thành công sẽ in `Server started on port 5679`. Cơ sở dữ liệu tự tạo và tự cập nhật khi khởi động (`npm run migrate` để chạy tay).

### 2. Giao diện

Mở cửa sổ dòng lệnh khác:

```bash
cd frontweb
npm install
npm run dev        # cổng 3013, tự chuyển /api và /static sang 5679
npm run build      # dựng lại frontweb/dist (máy chủ 5679 sẽ phục vụ bản này)
```

### 3. Tập lệnh khởi động

`run_dev.bat` / `run_dev.ps1` (bản gốc) mở cùng lúc máy chủ và giao diện chế độ phát triển ở hai cửa sổ.

---

## Đóng gói Windows exe (bản gốc)

```bash
cd desktop
npm install
npm run dist       # tạo bộ cài NSIS + bản chạy ngay
```

Kết quả ở `desktop/release/`. Quy trình: dựng giao diện → chép máy chủ và giao diện vào `desktop/` → electron-builder đóng gói.

---

## Tệp cấu hình

`backend-node/configs/config.yaml` (bản exe: `%APPDATA%\LocalMiniDrama\backend\configs\config.yaml`):

```yaml
app:
  language: vi        # vi = giao diện AI tiếng Việt, prompt ảnh/video tiếng Anh; en; zh

server:
  port: 5679          # cổng máy chủ
  # cors_open: false  # bật dòng này để chỉ cho phép các origin trong cors_origins (mặc định mở cho Bravin)
  cors_origins:
    - http://localhost:3012

database:
  path: ./data/drama_generator.db   # cơ sở dữ liệu SQLite

storage:
  local_path: ./data/storage        # nơi lưu ảnh/video tạo ra
  base_url: http://localhost:5679/static

style:
  default_style: realistic
  default_image_ratio: "16:9"
  default_video_ratio: "16:9"
```

Cấu hình dịch vụ AI quản lý trong trang **Cấu hình AI**, không cần sửa YAML.

---

## Dữ liệu

| Đường dẫn | Nội dung |
|------|------|
| `backend-node/data/drama_generator.db` | cơ sở dữ liệu SQLite |
| `backend-node/data/storage/` | ảnh, video, âm thanh tạo ra |
| `%APPDATA%\LocalMiniDrama\` | toàn bộ dữ liệu khi dùng bản exe |

> ⚠️ Sao lưu thư mục `data/` trước khi nâng cấp.

---

## Câu hỏi thường gặp

**Máy chủ báo `Cannot find module 'better-sqlite3'`**: chạy `npm install` trong `backend-node`. Vẫn lỗi thì nâng Node.js lên 18 trở lên. Đừng chép thư mục `node_modules` từ máy khác (thư viện này biên dịch riêng cho từng hệ điều hành).

**Giao diện báo `Failed to fetch` hoặc API 404**: kiểm tra máy chủ đã in `Server started on port 5679`; khi chạy `npm run dev` ở giao diện, `frontweb/vite.config.js` phải trỏ `proxy` tới `http://127.0.0.1:5679`.

**Không ghép được video cả tập**: cần ffmpeg. Gói tiếng Việt không kèm `ffmpeg.exe` (99 MB): chép nó từ gói LocalMiniDrama gốc vào `backend-node/tools/ffmpeg/`, xem `backend-node/tools/ffmpeg/README.md`. macOS/Linux: cài ffmpeg vào PATH.

**Ảnh/video lưu ở đâu?** `backend-node/data/storage/` (bản exe: `%APPDATA%\LocalMiniDrama\backend\data\storage\`).

**Sao lưu/chuyển dự án?** Trang chủ → nút xuất trên thẻ dự án (tệp ZIP) → nhập ở máy mới. Hoặc chép nguyên thư mục `data/`.

**Bravin không nối được?** Xem phần [Dùng cùng Bravin](../README.md#-dùng-cùng-bravin): khu Phim AI liệt kê từng bước kiểm tra kèm cách sửa.

---

[← Về trang chính](../README.md)
