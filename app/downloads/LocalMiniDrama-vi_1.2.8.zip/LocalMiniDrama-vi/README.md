<div align="center">

# 🎬 Phim AI · LocalMiniDrama (bản tiếng Việt)

**Công cụ làm phim ngắn & truyện tranh động bằng AI chạy trên máy: tải về là dùng, mã nguồn mở, dữ liệu không rời máy**

*LocalMiniDrama · AI-powered short drama creator*

[![version](https://img.shields.io/badge/version-1.2.8--vi-blue?style=flat-square)](https://github.com/xuanyustudio/LocalMiniDrama/releases)
[![license](https://img.shields.io/badge/license-MIT-green?style=flat-square)](LICENSE)
[![stack](https://img.shields.io/badge/Vue3%20%2B%20Node.js-informational?style=flat-square)](#-kiến-trúc)

**Tiếng Việt · [English](docs/en.md) · [简体中文 (bản gốc)](README.zh.md) · [Chuyện của tác giả (tiếng Trung)](docs/story.md)**

[**🚀 Bắt đầu nhanh**](#-bắt-đầu-nhanh) · [**🎞 Dùng cùng Bravin**](#-dùng-cùng-bravin) · [**📖 Cấu hình AI**](docs/configuration.md)

</div>

> Bản dịch tiếng Việt và cầu nối Bravin do Bravin thực hiện trên mã nguồn MIT của **xuanyustudio/LocalMiniDrama** (bản 1.2.8). Mọi công sức tạo ra công cụ thuộc về tác giả gốc.

---

<table>
<tr>
<td width="25%" align="center"><b>🔒 Ưu tiên chạy trên máy</b><br/>SQLite + tệp trên máy, tư liệu không lên mây</td>
<td width="25%" align="center"><b>🎬 Trọn quy trình</b><br/>Kịch bản → nhân vật/bối cảnh → phân cảnh → ghép video</td>
<td width="25%" align="center"><b>🤖 Nhiều mô hình</b><br/>Tongyi / Volcengine / Kling / Gemini…</td>
<td width="25%" align="center"><b>🗺 Hai chế độ xem</b><br/>Danh sách để sửa kỹ + canvas để xếp hàng loạt</td>
</tr>
</table>

Công cụ làm phim ngắn bằng AI thì nhiều, nhưng gần như không có cái nào **chạy được trên máy, mở là dùng, tư liệu không lên mây**. Dự án viết hoàn toàn bằng JavaScript, nối với API AI của chính bạn, mở ra là tạo được cả một bộ phim ngắn.

> ✅ Không thu phí thuê bao · ✅ Dữ liệu lưu trên máy · ✅ Nhiều nhà cung cấp AI · ✅ Mã nguồn mở, sửa tiếp được

---

## 🇻🇳 Bản tiếng Việt có gì khác

- **Toàn bộ giao diện và thông báo lỗi** đã dịch sang tiếng Việt (khoảng 2.400 chuỗi), lịch và hộp thoại Element Plus cũng tiếng Việt.
- **Ngôn ngữ AI "vi"** (mặc định): AI viết truyện, kịch bản, thoại, thuyết minh, tên tập… **bằng tiếng Việt**, còn prompt gửi cho mô hình tạo ảnh/video **giữ tiếng Anh** để ảnh đẹp và ổn định. Đổi trong `backend-node/configs/config.yaml` (`app.language: vi | en | zh`) hoặc ô «Ngôn ngữ phân cảnh» ở trang sản xuất.
- **Tách tập/chương tiếng Việt**: kịch bản có dòng `Tập 1`, `Chương 2`, `Episode 3` được tự tách thành nhiều tập; nhập tiểu thuyết nhận `Chương N`, `Hồi N`, `Chapter N` (vẫn nhận `第N章` như bản gốc).
- **Cầu nối Bravin**: chạy trong khu «Phim AI» của Bravin, tự đẩy ảnh/video/âm thanh tạo xong vào thư viện, nút **＋ Dự án** tạo dự án Bravin cùng tên phim. Xem [Dùng cùng Bravin](#-dùng-cùng-bravin).
- Giữ nguyên: mẫu prompt tiếng Trung trong `promptI18n.js` (dùng khi chọn `zh`), ký hiệu `@图片N` (đây là cú pháp mà Seedance/Kling yêu cầu, không được dịch).

---

## ✨ Tính năng chính

| Bước | Chức năng | Mô tả |
|:----:|------|------|
| 1 | **Tạo truyện** | Nhập tóm tắt + phong cách, AI viết kịch bản nhiều tập |
| 2 | **Sửa kịch bản** | Quản lý từng tập, sửa văn bản tự do |
| 3 | **Tạo nhân vật** | AI trích danh sách nhân vật, tạo ảnh tạo hình từng người |
| 4 | **Tạo bối cảnh** | Trích bối cảnh từ kịch bản, tạo ảnh nền |
| 5 | **Tạo đạo cụ** | Trích hoặc tự thêm đạo cụ, tạo ảnh đạo cụ |
| 6 | **Tạo phân cảnh** | Tạo kịch bản phân cảnh cho từng tập (cỡ cảnh / chuyển động máy / thoại) |
| 7 | **Tạo ảnh/video** | Tạo ảnh tĩnh và đoạn video cho từng cảnh |
| 8 | **Ghép video** | Ghép tất cả video phân cảnh thành tệp cả tập |

**Quy trình một chạm · Quản lý dự án · Sửa phân cảnh**

- **Tạo một chạm / Bổ sung và tạo**: tự động từ nhân vật đến video ghép; tự bỏ qua phần đã có.
- **Tự thử lại khi lỗi**: mỗi bước tối đa 3 lần (chống giới hạn tốc độ); tiến độ và nhật ký lỗi theo thời gian thực.
- **Xuất/nhập dự án ZIP** · **Thư viện tư liệu chung** · **Khung 16:9 / 9:16 / 1:1**.
- **Phân cảnh cổ điển / toàn năng** · **tham chiếu nhiều ảnh `@图片N`** · **nối khung cuối** · **xuất bảng phân cảnh HTML** · **SRT thuyết minh**.
- Sửa toàn văn **prompt ảnh/video** · tải lên/kéo thả thay ảnh tham chiếu.

**Canvas (kiểu LibTV)**: trang sản xuất → **Chế độ canvas** (`/film/:id/canvas`), dùng chung dữ liệu với chế độ danh sách: dây chuyền theo hàng, nút kịch bản, bảng thao tác trên nút, chuột phải / thanh công cụ, nhóm workflow **chạy lại cả nhóm**, lưu bố cục.

**Cấu hình AI · Giao diện sáng/tối · Prompt tuỳ chỉnh**: ba loại mô hình (văn bản/ảnh/video) cấu hình riêng; cấu hình nhanh Tongyi/Volcengine/Agnes; 9 loại prompt có thể ghi đè.

---

## 🚀 Bắt đầu nhanh

> Cần **Node.js 18 trở lên** (tải ở https://nodejs.org, chọn bản LTS).

**Windows** – bấm đúp **`CHAY_PHIM_AI.bat`** ở thư mục gốc. Lần đầu nó cài thư viện (vài phút, cần mạng), sau đó mở trình duyệt ở `http://localhost:5679`.

**macOS / Linux**:

```bash
bash chay_phim_ai.sh
```

Hoặc tự chạy:

```bash
cd backend-node
npm install --omit=dev
npm start          # cổng 5679, phục vụ luôn giao diện đã dựng sẵn ở frontweb/dist
```

**ffmpeg** (để ghép video cả tập): gói này không kèm `ffmpeg.exe` cho nhẹ; chép nó từ gói LocalMiniDrama gốc vào `backend-node/tools/ffmpeg/` (xem README trong đó).

Sau đó vào **Cấu hình AI** (góc trên phải) → thêm API Key → bắt đầu sáng tác.

Muốn sửa mã giao diện: `cd frontweb && npm install && npm run dev` (cổng 3013, tự chuyển API sang 5679), rồi `npm run build` để dựng lại `frontweb/dist`.

📖 [Hướng dẫn chạy & đóng gói chi tiết](docs/quickstart.md) · [Hướng dẫn cấu hình AI](docs/configuration.md)

---

## 🎞 Dùng cùng Bravin

Bravin 4.10 có khu **Phim AI** (nút «Phim AI» trên thanh trên cùng, hoặc ô «Phim AI» ở Trang chủ):

1. Chạy LocalMiniDrama trên máy (bước trên). Mở Bravin → **Phim AI**.
2. Bravin **kiểm tra độ tương thích**: máy chủ có chạy không, có cầu nối Bravin không, đọc tệp được không (CORS), API dự án, ffmpeg, ngôn ngữ AI. Mục nào lỗi đều có cách sửa ngay bên dưới.
3. Đạt yêu cầu thì giao diện LocalMiniDrama mở ngay trong Bravin.
4. **Tự đẩy vào thư viện**: mỗi khi LocalMiniDrama tạo **thành công** ảnh phân cảnh, video phân cảnh, lồng tiếng, thuyết minh, ảnh nhân vật/bối cảnh/đạo cụ hay video cả tập, tệp được nhập thẳng vào thư viện của dự án Bravin đang mở, trong nhóm **«Phim AI»**, tên dạng `Phim AI · T1 · C03 · video.mp4`. Khu Phim AI đóng lại vẫn tiếp tục đồng bộ.
   - Lần đầu nối một phim với một dự án, tệp cũ không bị đổ vào hàng loạt; bấm **⇪ Đẩy** để nhập chúng.
5. **＋ Dự án** (góc dưới phải trong LocalMiniDrama, hoặc trên thanh của khu Phim AI): tạo **dự án Bravin mới cùng tên với phim đang làm**, khung hình theo tỉ lệ của phim, rồi nhập sẵn mọi tệp đã có.

Đổi cổng/địa chỉ: sửa ô địa chỉ trên thanh khu Phim AI (mặc định `http://localhost:5679`). Bravin chạy qua https chỉ nối được LocalMiniDrama trên chính máy đó (`localhost`).

---

## 🤖 Nhà cung cấp AI

| Nhà cung cấp | Văn bản | Ảnh | Video |
|--------|:----:|:----:|:----:|
| Alibaba DashScope (Tongyi) | ✅ | ✅ | ✅ |
| Volcengine (Doubao / Seedance 2.0) | ✅ | ✅ | ✅ |
| Kling AI (có Omni) | — | ✅ | ✅ |
| Agnes AI | ✅ | ✅ | ✅ |
| Google Gemini (Imagen / Veo) | — | ✅ | ✅ |
| Vidu | — | — | ✅ |
| NanoBanana (có proxy) | — | ✅ | — |
| Ollama và mô hình chạy máy tương thích OpenAI | ✅ | — | — |
| Giao diện khác tương thích OpenAI (DeepSeek, OpenRouter…) | ✅ | ✅ | — |

---

## 🏗 Kiến trúc

```
LocalMiniDrama/
├── backend-node/     # Express + SQLite: tạo / ghép / nhập xuất, phục vụ giao diện
├── frontweb/         # Vue 3 + Element Plus + @vue-flow/core (dist/ đã dựng sẵn)
│   └── src/utils/bravinBridge.js   # cầu nối Bravin (postMessage)
├── desktop/          # đóng gói Electron (bản gốc)
└── docs/             # tài liệu
```

| Lớp | Công nghệ |
|----|------|
| Giao diện | Vue 3 · Vite · Element Plus · Pinia · @vue-flow/core |
| Máy chủ | Node.js · Express · SQLite (better-sqlite3) |
| Desktop | Electron 28 · electron-builder |

---

## 📄 Giấy phép

[MIT](LICENSE) © xuanyustudio. Bản dịch và cầu nối Bravin phát hành theo cùng giấy phép MIT.
Tài liệu còn tiếng Trung (chưa dịch): `CHANGELOG.md`, `docs/plans/`, `docs/superpowers/`, `docs/comfyui资料1.md`, `backend-node/README.md`, `desktop/README.md`, `openclaw-skill/`.
