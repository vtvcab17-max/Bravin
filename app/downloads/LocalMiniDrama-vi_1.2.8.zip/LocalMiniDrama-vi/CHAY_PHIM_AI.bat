@echo off
chcp 65001 >nul
title Phim AI - LocalMiniDrama (tieng Viet)
set ROOT=%~dp0
where node >nul 2>&1
if errorlevel 1 (
  echo [!] Chua co Node.js. Tai ban LTS tai https://nodejs.org roi chay lai tep nay.
  start https://nodejs.org
  pause
  exit /b 1
)
for /f "tokens=2 delims=v." %%v in ('node -v') do set NODEMAJ=%%v
if %NODEMAJ% LSS 18 (
  echo [!] Can Node.js 18 tro len. May dang dung:
  node -v
  pause
  exit /b 1
)
cd /d "%ROOT%backend-node"
if not exist node_modules\better-sqlite3 (
  echo [1/2] Lan dau: dang cai thu vien (vai phut, can mang)...
  call npm install --omit=dev --no-audit --no-fund
  if errorlevel 1 (
    echo [!] Cai thu vien that bai. Kiem tra mang roi chay lai.
    pause
    exit /b 1
  )
)
if not exist tools\ffmpeg\ffmpeg.exe (
  where ffmpeg >nul 2>&1 || echo [i] Chua co ffmpeg: van tao anh/video duoc, nhung khong ghep duoc ca tap. Xem backend-node\tools\ffmpeg\README.md
)
echo [2/2] Dang chay may chu o http://localhost:5679  (dong cua so nay de tat)
start "" cmd /c "timeout /t 4 /nobreak >nul && start http://localhost:5679"
node src\server.js
pause
